/* =========================================================================
   MUMBAI CONNECT — Map helpers (map.js)
   Leaflet + OpenStreetMap tiles. No API key required.
   ========================================================================= */

const MUMBAI_CENTER = { lat: 19.0760, lng: 72.8777 };

function addOsmTiles(map) {
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19, attribution: '&copy; OpenStreetMap contributors',
  }).addTo(map);
}

/**
 * Interactive picker: click or drag a marker to set a location.
 * Writes into the given lat/lng hidden inputs and a status line.
 */
function initLocationPicker(mapElId, latFieldId, lngFieldId, statusElId, initialLat, initialLng, onChange) {
  const map = L.map(mapElId).setView([initialLat || MUMBAI_CENTER.lat, initialLng || MUMBAI_CENTER.lng], initialLat ? 15 : 11);
  addOsmTiles(map);
  const latField = document.getElementById(latFieldId);
  const lngField = document.getElementById(lngFieldId);
  const statusEl = document.getElementById(statusElId);
  let marker = null;

  function place(lat, lng) {
    if (marker) marker.setLatLng([lat, lng]);
    else {
      marker = L.marker([lat, lng], { draggable: true }).addTo(map);
      marker.on('dragend', () => { const p = marker.getLatLng(); update(p.lat, p.lng); });
    }
    map.panTo([lat, lng]);
  }
  function update(lat, lng) {
    place(lat, lng);
    if (latField) latField.value = lat;
    if (lngField) lngField.value = lng;
    if (statusEl) {
      statusEl.textContent = `Selected location: ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
      statusEl.className = 'text-success small mt-2';
    }
    if (typeof onChange === 'function') onChange(lat, lng);
  }

  map.on('click', (e) => update(e.latlng.lat, e.latlng.lng));

  if (initialLat && initialLng) update(initialLat, initialLng);

  return { setLocation: update };
}

/** Static single-marker map for viewing a complaint's location. */
function initStaticMap(mapElId, lat, lng, popupText) {
  const map = L.map(mapElId).setView([lat, lng], 16);
  addOsmTiles(map);
  L.marker([lat, lng]).addTo(map).bindPopup(escapeHtml(popupText)).openPopup();
  return map;
}

/**
 * Hotspot visualization. Uses leaflet.heat if it loaded successfully
 * (via CDN); otherwise falls back to semi-transparent circle markers so
 * the feature still works without the extra dependency.
 */
function initHeatmap(mapElId, points) {
  const map = L.map(mapElId).setView([MUMBAI_CENTER.lat, MUMBAI_CENTER.lng], 11);
  addOsmTiles(map);

  if (typeof L.heatLayer === 'function' && points.length) {
    L.heatLayer(points.map(p => [p[0], p[1], 0.6]), { radius: 28, blur: 22, maxZoom: 15 }).addTo(map);
  } else {
    points.forEach(p => {
      L.circleMarker([p[0], p[1]], { radius: 7, color: '#B23A48', fillColor: '#B23A48', fillOpacity: 0.35, weight: 0 }).addTo(map);
    });
  }
  return map;
}
