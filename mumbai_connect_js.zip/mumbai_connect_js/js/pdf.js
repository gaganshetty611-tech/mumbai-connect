/* =========================================================================
   MUMBAI CONNECT — PDF report export (pdf.js)
   Uses jsPDF (loaded via CDN in the page). Builds a simple, clean
   complaints summary report the admin can download.
   ========================================================================= */

function downloadComplaintsReportPDF() {
  if (!window.jspdf) {
    showToast('PDF library did not load — check your internet connection and try again.', 'error');
    return;
  }
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const complaints = getComplaints().slice().sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  const wards = getWards();

  doc.setFont('helvetica', 'bold');
  doc.setFontSize(16);
  doc.setTextColor(17, 75, 156);
  doc.text('Mumbai Connect — Civic Complaints Report', 14, 18);

  doc.setFontSize(10);
  doc.setTextColor(90, 97, 122);
  doc.setFont('helvetica', 'normal');
  doc.text('Generated: ' + new Date().toLocaleString('en-IN'), 14, 25);

  const total = complaints.length;
  const resolved = complaints.filter(c => c.status === 'RESOLVED' || c.status === 'CLOSED').length;
  const pending = total - resolved;
  doc.text(`Total: ${total}   |   Resolved: ${resolved}   |   Pending: ${pending}`, 14, 31);

  let y = 42;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(9);
  doc.setTextColor(17, 75, 156);
  doc.text('ID', 14, y);
  doc.text('Category', 45, y);
  doc.text('Status', 90, y);
  doc.text('Ward', 125, y);
  doc.text('Filed On', 145, y);
  y += 2;
  doc.setDrawColor(227, 233, 242);
  doc.line(14, y, 196, y);
  y += 5;

  doc.setFont('helvetica', 'normal');
  doc.setTextColor(20, 26, 40);
  complaints.slice(0, 400).forEach((c) => {
    if (y > 280) { doc.addPage(); y = 20; }
    const ward = wards.find(w => w.id === c.wardId);
    doc.text(c.complaintId, 14, y);
    doc.text(categoryMeta(c.category).label.slice(0, 22), 45, y);
    doc.text(statusLabel(c.status), 90, y);
    doc.text(ward ? ward.code : '—', 125, y);
    doc.text(formatDate(c.createdAt), 145, y);
    y += 6;
  });

  doc.save('mumbai-connect-report.pdf');
}
