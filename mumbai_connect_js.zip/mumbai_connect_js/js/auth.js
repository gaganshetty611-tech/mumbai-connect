/* =========================================================================
   MUMBAI CONNECT — Auth (auth.js)
   Client-side session handling. NOTE: this is a front-end demo — passwords
   are stored in plain text in the browser's localStorage. That's fine for
   a portfolio/demo build, but do not reuse this pattern for anything with
   real user data. A real deployment needs a real backend (hashing,
   server-side sessions, etc.) — see README.
   ========================================================================= */

function currentUser() {
  const session = dbGet(DB_KEYS.SESSION, null);
  if (!session) return null;
  return getUserById(session.userId) || null;
}

function isLoggedIn() { return !!currentUser(); }

function isStaff(user) {
  user = user || currentUser();
  return !!user && (user.role === 'ADMIN' || user.role === 'OFFICER');
}

function login(username, password) {
  const user = getUserByUsername(username);
  if (!user || user.password !== password) {
    return { ok: false, error: 'Invalid username or password.' };
  }
  dbSet(DB_KEYS.SESSION, { userId: user.id });
  return { ok: true, user };
}

function logout() {
  localStorage.removeItem(DB_KEYS.SESSION);
}

function signup(fields) {
  if (getUserByUsername(fields.username)) {
    return { ok: false, error: 'That username is already taken.' };
  }
  const users = getUsers();
  const user = {
    id: uid('u'), username: fields.username, password: fields.password, role: 'CITIZEN',
    firstName: fields.firstName, lastName: fields.lastName, email: fields.email,
    phone: fields.phone, wardId: fields.wardId || null, address: fields.address || '',
    profilePhoto: null, createdAt: new Date().toISOString(),
  };
  users.push(user);
  saveUsers(users);
  dbSet(DB_KEYS.SESSION, { userId: user.id });
  return { ok: true, user };
}

/**
 * Guard a page: redirect to login if not authenticated, or to the
 * dashboard if `staffOnly` is required and the user isn't staff.
 * Call at the top of any protected page's inline script.
 */
function requireAuth(opts) {
  opts = opts || {};
  const user = currentUser();
  if (!user) {
    window.location.href = 'login.html?next=' + encodeURIComponent(window.location.pathname.split('/').pop());
    return null;
  }
  if (opts.staffOnly && !isStaff(user)) {
    window.location.href = 'dashboard.html';
    return null;
  }
  if (opts.citizenOnly && isStaff(user)) {
    window.location.href = 'admin-dashboard.html';
    return null;
  }
  return user;
}

function redirectIfLoggedIn() {
  const user = currentUser();
  if (user) {
    window.location.href = isStaff(user) ? 'admin-dashboard.html' : 'dashboard.html';
  }
}
