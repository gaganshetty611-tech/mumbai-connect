/* =========================================================================
   MUMBAI CONNECT — Shared UI (ui.js)
   Navbar/footer injection, theme toggle, toasts, pagination, image
   compression, geolocation. Every page calls initPage() once on load.
   ========================================================================= */

/* ---------------------------- Theme ---------------------------- */

function initTheme() {
  const saved = dbGet(DB_KEYS.THEME, null) || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  document.documentElement.setAttribute('data-theme', saved);
}

function toggleTheme() {
  const cur = document.documentElement.getAttribute('data-theme') || 'light';
  const next = cur === 'dark' ? 'light' : 'dark';
  document.documentElement.setAttribute('data-theme', next);
  dbSet(DB_KEYS.THEME, next);
  const icon = document.getElementById('theme-icon');
  if (icon) icon.className = next === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';
}

/* ---------------------------- Navbar ---------------------------- */

function renderNavbar(active) {
  const root = document.getElementById('navbar-root');
  if (!root) return;
  const user = currentUser();
  const theme = document.documentElement.getAttribute('data-theme') || 'light';
  const unread = user ? getNotificationsForUser(user.id).filter(n => !n.isRead).length : 0;

  const navLink = (href, label, key) =>
    `<li class="nav-item"><a class="nav-link ${active === key ? 'active' : ''}" href="${href}">${label}</a></li>`;

  let links = '';
  links += navLink('index.html', 'Home', 'home');
  links += navLink('about.html', 'About', 'about');

  if (user && isStaff(user)) {
    links += navLink('admin-dashboard.html', 'Admin Dashboard', 'admin-dashboard');
    links += navLink('admin-complaints.html', 'Manage Complaints', 'admin-complaints');
    links += navLink('admin-analytics.html', 'Analytics', 'admin-analytics');
  } else if (user) {
    links += navLink('dashboard.html', 'Dashboard', 'dashboard');
    links += navLink('submit-complaint.html', 'Submit Complaint', 'submit');
    links += navLink('complaint-history.html', 'History', 'history');
  } else {
    links += navLink('track-complaint.html', 'Track Complaint', 'track');
  }
  links += navLink('faq.html', 'FAQ', 'faq');
  links += navLink('contact.html', 'Contact', 'contact');

  let rightSide = '';
  if (user) {
    rightSide = `
      <a href="notifications.html" class="icon-btn" title="Notifications">
        <i class="bi bi-bell-fill"></i>
        ${unread > 0 ? `<span class="notif-dot">${unread}</span>` : ''}
      </a>
      <div class="dropdown">
        <button class="btn btn-light rounded-pill px-3 dropdown-toggle" type="button" data-bs-toggle="dropdown">
          <i class="bi bi-person-circle me-1"></i> ${escapeHtml(user.firstName || user.username)}
        </button>
        <ul class="dropdown-menu dropdown-menu-end">
          <li><a class="dropdown-item" href="profile.html"><i class="bi bi-person me-2"></i>My Profile</a></li>
          <li><hr class="dropdown-divider"></li>
          <li><a class="dropdown-item text-danger" href="#" id="logout-link"><i class="bi bi-box-arrow-right me-2"></i>Logout</a></li>
        </ul>
      </div>`;
  } else {
    rightSide = `
      <a href="login.html" class="btn btn-outline-light rounded-pill px-3">Login</a>
      <a href="signup.html" class="btn btn-mc-success rounded-pill px-3">Sign Up</a>`;
  }

  root.innerHTML = `
  <nav class="navbar navbar-expand-lg mc-navbar">
    <div class="container">
      <a class="navbar-brand" href="index.html">
        <span class="brand-mark">MC</span> Mumbai Connect
      </a>
      <button class="navbar-toggler text-white border-0" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav">
        <i class="bi bi-list text-white fs-2"></i>
      </button>
      <div class="collapse navbar-collapse" id="mainNav">
        <ul class="navbar-nav me-auto ms-lg-4">${links}</ul>
        <div class="d-flex align-items-center gap-2">
          <button class="icon-btn" onclick="toggleTheme()" title="Toggle dark / light mode">
            <i id="theme-icon" class="bi ${theme === 'dark' ? 'bi-sun-fill' : 'bi-moon-stars-fill'}"></i>
          </button>
          ${rightSide}
        </div>
      </div>
    </div>
  </nav>`;

  const logoutLink = document.getElementById('logout-link');
  if (logoutLink) {
    logoutLink.addEventListener('click', (e) => {
      e.preventDefault();
      logout();
      window.location.href = 'index.html';
    });
  }
}

/* ---------------------------- Footer ---------------------------- */

function renderFooter() {
  const root = document.getElementById('footer-root');
  if (!root) return;
  const emergencyRows = EMERGENCY_CONTACTS.map(([name, num]) =>
    `<div class="emergency-item"><span>${name}</span><span class="num">${num}</span></div>`).join('');

  root.innerHTML = `
  <footer class="mc-footer">
    <div class="container">
      <div class="row g-4">
        <div class="col-lg-4">
          <h6><span class="brand-mark d-inline-flex align-items-center justify-content-center" style="width:30px;height:30px;border-radius:8px;font-size:0.8rem;">MC</span> Mumbai Connect</h6>
          <p class="small">A Smart Civic Complaint Management System empowering Mumbai citizens to report and track civic issues — building a cleaner, safer, better city together.</p>
        </div>
        <div class="col-lg-2 col-6">
          <h6>Quick Links</h6>
          <ul class="list-unstyled small">
            <li class="mb-2"><a href="about.html">About Us</a></li>
            <li class="mb-2"><a href="faq.html">FAQ</a></li>
            <li class="mb-2"><a href="track-complaint.html">Track Complaint</a></li>
            <li class="mb-2"><a href="contact.html">Contact</a></li>
          </ul>
        </div>
        <div class="col-lg-3 col-6">
          <h6>Contact</h6>
          <ul class="list-unstyled small">
            <li class="mb-2"><i class="bi bi-geo-alt me-2"></i>BMC Head Office, Fort, Mumbai 400001</li>
            <li class="mb-2"><i class="bi bi-envelope me-2"></i>support@mumbaiconnect.gov.in</li>
            <li class="mb-2"><i class="bi bi-telephone me-2"></i>1800-22-1234 (Toll Free)</li>
          </ul>
        </div>
        <div class="col-lg-3">
          <h6>Emergency Numbers</h6>
          ${emergencyRows}
        </div>
      </div>
      <hr class="border-secondary mt-4">
      <div class="text-center small">
        &copy; <span id="footer-year"></span> Mumbai Connect — A Smart City Initiative. Academic Demonstration Project.
        &nbsp;·&nbsp; <a href="#" id="reset-demo-link">Reset demo data</a>
      </div>
    </div>
  </footer>`;
  const yearEl = document.getElementById('footer-year');
  if (yearEl) yearEl.textContent = new Date().getFullYear();

  const resetLink = document.getElementById('reset-demo-link');
  if (resetLink) {
    resetLink.addEventListener('click', (e) => {
      e.preventDefault();
      if (confirm('This clears all local data (users, complaints, notifications) and reloads fresh demo data. Continue?')) {
        resetDemoData();
      }
    });
  }
}

/** Wipes everything this app stores in localStorage and reloads with a fresh seed. */
function resetDemoData() {
  Object.values(DB_KEYS).forEach(k => localStorage.removeItem(k));
  window.location.href = 'index.html';
}

/* ---------------------------- Toasts ---------------------------- */

function showToast(message, type) {
  type = type || 'success';
  let stack = document.querySelector('.toast-stack');
  if (!stack) {
    stack = document.createElement('div');
    stack.className = 'toast-stack';
    document.body.appendChild(stack);
  }
  const colors = { success: 'success', error: 'danger', warning: 'warning', info: 'primary' };
  const el = document.createElement('div');
  el.className = `alert alert-${colors[type] || 'primary'} shadow`;
  el.style.cssText = 'animation: fadeIn .3s ease;';
  el.innerHTML = message;
  stack.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; setTimeout(() => el.remove(), 300); }, 4000);
}

/* ---------------------------- Pagination ---------------------------- */

function paginate(array, page, perPage) {
  page = Math.max(1, page || 1);
  const totalPages = Math.max(1, Math.ceil(array.length / perPage));
  page = Math.min(page, totalPages);
  const start = (page - 1) * perPage;
  return { items: array.slice(start, start + perPage), page, totalPages, total: array.length };
}

function renderPaginationControls(containerId, page, totalPages, onPageChangeFnName) {
  const el = document.getElementById(containerId);
  if (!el) return;
  if (totalPages <= 1) { el.innerHTML = ''; return; }
  let html = '<ul class="pagination justify-content-center mb-0">';
  html += `<li class="page-item ${page <= 1 ? 'disabled' : ''}"><a class="page-link" href="#" onclick="${onPageChangeFnName}(${page - 1});return false;">Previous</a></li>`;
  for (let p = 1; p <= totalPages; p++) {
    html += `<li class="page-item ${p === page ? 'active' : ''}"><a class="page-link" href="#" onclick="${onPageChangeFnName}(${p});return false;">${p}</a></li>`;
  }
  html += `<li class="page-item ${page >= totalPages ? 'disabled' : ''}"><a class="page-link" href="#" onclick="${onPageChangeFnName}(${page + 1});return false;">Next</a></li>`;
  html += '</ul>';
  el.innerHTML = html;
}

/* ---------------------------- Images ---------------------------- */

/** Reads + downsizes an image file to a compressed JPEG data URL (keeps localStorage usage sane). */
function compressImageFile(file, maxWidth, quality) {
  maxWidth = maxWidth || 900;
  quality = quality || 0.7;
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Could not read file.'));
    reader.onload = (e) => {
      const img = new Image();
      img.onerror = () => reject(new Error('Could not decode image.'));
      img.onload = () => {
        const scale = Math.min(1, maxWidth / img.width);
        const canvas = document.createElement('canvas');
        canvas.width = img.width * scale;
        canvas.height = img.height * scale;
        const ctx = canvas.getContext('2d');
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', quality));
      };
      img.src = e.target.result;
    };
    reader.readAsDataURL(file);
  });
}

/* ---------------------------- Geolocation ---------------------------- */

function detectLocation() {
  return new Promise((resolve, reject) => {
    if (!navigator.geolocation) { reject(new Error('Geolocation is not supported by your browser.')); return; }
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => reject(new Error('Could not detect your location. Please select it on the map instead.'))
    );
  });
}

/* ---------------------------- Civic pulse ticker (homepage signature element) ---------------------------- */

function buildPulseMessages() {
  const complaints = getComplaints().slice().sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt)).slice(0, 12);
  const wards = getWards();
  return complaints.map(c => {
    const ward = wards.find(w => w.id === c.wardId);
    const cat = categoryMeta(c.category);
    const verb = c.status === 'RESOLVED' || c.status === 'CLOSED' ? 'marked ' + statusLabel(c.status) : 'reported';
    return `${c.complaintId} · ${cat.label} ${verb} in ${ward ? ward.code : '—'} · ${timeAgo(c.updatedAt)}`;
  });
}

function initPulseTicker(elId) {
  const el = document.getElementById(elId);
  if (!el) return;
  const messages = buildPulseMessages();
  if (messages.length === 0) { el.parentElement.style.display = 'none'; return; }
  let i = 0;
  const show = () => { el.textContent = messages[i % messages.length]; i++; };
  show();
  setInterval(show, 3200);
}

/* ---------------------------- Misc ---------------------------- */

function escapeHtml(str) {
  if (str == null) return '';
  return String(str).replace(/[&<>"']/g, (m) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
}

function qs(name) {
  return new URLSearchParams(window.location.search).get(name);
}

/** Call once at the top of every page. */
function initPage(opts) {
  opts = opts || {};
  seedIfNeeded();
  initTheme();
  renderNavbar(opts.active);
  renderFooter();
}
