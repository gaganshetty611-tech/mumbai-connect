/* =========================================================================
   MUMBAI CONNECT — Data Layer (db.js)
   A self-contained "database" backed by localStorage. No server required.
   Everything the app needs — users, wards, officers, complaints,
   notifications — lives here, seeded once on first load.
   ========================================================================= */

const DB_KEYS = {
  SEEDED: 'mc_seeded_v1',
  USERS: 'mc_users',
  WARDS: 'mc_wards',
  OFFICERS: 'mc_officers',
  COMPLAINTS: 'mc_complaints',
  NOTIFICATIONS: 'mc_notifications',
  SESSION: 'mc_session',
  THEME: 'mc_theme',
  COMPLAINT_SEQ: 'mc_complaint_seq',
};

/* ---------------------------- Constants ---------------------------- */

const CATEGORIES = [
  { value: 'GARBAGE',         label: 'Garbage Dump',            icon: 'bi-trash3-fill',            color: 'var(--cat-garbage)' },
  { value: 'POTHOLE',         label: 'Pothole',                 icon: 'bi-cone-striped',           color: 'var(--cat-pothole)' },
  { value: 'SEWAGE',          label: 'Sewage Overflow',         icon: 'bi-droplet-fill',           color: 'var(--cat-sewage)' },
  { value: 'FOOTPATH',        label: 'Broken Footpath',         icon: 'bi-signpost-split-fill',    color: 'var(--cat-footpath)' },
  { value: 'WATERLOGGING',    label: 'Waterlogging',            icon: 'bi-water',                  color: 'var(--cat-waterlog)' },
  { value: 'STREETLIGHT',     label: 'Streetlight Not Working', icon: 'bi-lightbulb-fill',         color: 'var(--cat-streetlight)' },
  { value: 'ILLEGAL_DUMPING', label: 'Illegal Dumping',         icon: 'bi-exclamation-octagon-fill', color: 'var(--cat-illegal)' },
  { value: 'OTHER',           label: 'Other',                   icon: 'bi-three-dots',             color: 'var(--cat-other)' },
];

const STATUSES = [
  { value: 'SUBMITTED',     label: 'Submitted',     pct: 0 },
  { value: 'UNDER_REVIEW',  label: 'Under Review',  pct: 20 },
  { value: 'ASSIGNED',      label: 'Assigned',      pct: 40 },
  { value: 'IN_PROGRESS',   label: 'In Progress',   pct: 60 },
  { value: 'RESOLVED',      label: 'Resolved',      pct: 80 },
  { value: 'CLOSED',        label: 'Closed',        pct: 100 },
];

const PRIORITIES = ['LOW', 'MEDIUM', 'HIGH', 'CRITICAL'];

const DEPARTMENTS = ['Sanitation Department', 'Roads & Infrastructure', 'Water & Sewage', 'Electrical / Streetlights', 'General Administration'];

const EMERGENCY_CONTACTS = [
  ['Disaster Management Cell (BMC)', '1916'],
  ['Police', '100'],
  ['Ambulance', '108'],
  ['Fire Brigade', '101'],
  ['Women Helpline', '1091'],
];

const MUMBAI_WARDS = [
  ['A', 'Colaba, Fort, Churchgate', 'City', 18.9218, 72.8331],
  ['B', 'Dongri, Mandvi', 'City', 18.9547, 72.8352],
  ['C', 'Marine Lines, Kalbadevi', 'City', 18.9469, 72.8258],
  ['D', 'Malabar Hill, Grant Road', 'City', 18.9548, 72.8090],
  ['E', 'Byculla, Mazgaon', 'City', 18.9750, 72.8347],
  ['F/N', 'Matunga, Sion', 'City', 19.0332, 72.8560],
  ['F/S', 'Parel, Lower Parel', 'City', 19.0018, 72.8339],
  ['G/N', 'Dadar, Dharavi', 'City', 19.0176, 72.8562],
  ['G/S', 'Worli, Elphinstone', 'City', 19.0096, 72.8175],
  ['H/E', 'Bandra East, Khar East', 'Western Suburbs', 19.0596, 72.8656],
  ['H/W', 'Bandra West, Khar West', 'Western Suburbs', 19.0596, 72.8295],
  ['K/E', 'Andheri East, Jogeshwari East', 'Western Suburbs', 19.1136, 72.8697],
  ['K/W', 'Andheri West, Versova', 'Western Suburbs', 19.1197, 72.8464],
  ['P/N', 'Malad', 'Western Suburbs', 19.1874, 72.8484],
  ['P/S', 'Goregaon', 'Western Suburbs', 19.1663, 72.8526],
  ['R/C', 'Borivali', 'Western Suburbs', 19.2307, 72.8567],
  ['R/N', 'Dahisar', 'Western Suburbs', 19.2540, 72.8590],
  ['R/S', 'Kandivali', 'Western Suburbs', 19.2094, 72.8526],
  ['L', 'Kurla', 'Eastern Suburbs', 19.0728, 72.8826],
  ['M/E', 'Chembur East, Mankhurd', 'Eastern Suburbs', 19.0483, 72.9186],
  ['M/W', 'Chembur West', 'Eastern Suburbs', 19.0522, 72.9005],
  ['N', 'Ghatkopar', 'Eastern Suburbs', 19.0864, 72.9082],
  ['S', 'Bhandup, Powai', 'Eastern Suburbs', 19.1197, 72.9051],
  ['T', 'Mulund', 'Eastern Suburbs', 19.1726, 72.9425],
];

const DUPLICATE_RADIUS_METERS = 150;
const DUPLICATE_WINDOW_DAYS = 7;
const MAX_PHOTOS_PER_COMPLAINT = 3;

/* ---------------------------- Low-level storage ---------------------------- */

function dbGet(key, fallback) {
  try {
    const raw = localStorage.getItem(key);
    return raw ? JSON.parse(raw) : fallback;
  } catch (e) {
    console.error('DB read error for', key, e);
    return fallback;
  }
}

function dbSet(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (e) {
    console.error('DB write error for', key, e);
    return false;
  }
}

function uid(prefix) {
  return prefix + '_' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

/* ---------------------------- Seed data ---------------------------- */

function seedIfNeeded() {
  if (dbGet(DB_KEYS.SEEDED, false)) return;

  // Wards
  const wards = MUMBAI_WARDS.map((w, i) => ({
    id: 'ward_' + (i + 1), code: w[0], name: w[1], zone: w[2], lat: w[3], lng: w[4],
  }));
  dbSet(DB_KEYS.WARDS, wards);

  // Users: 1 admin, 5 officers, 10 citizens
  const users = [];
  users.push({
    id: uid('u'), username: 'admin', password: 'Admin@1234', role: 'ADMIN',
    firstName: 'System', lastName: 'Administrator', email: 'admin@mumbaiconnect.gov.in',
    phone: '9800000000', wardId: null, address: 'BMC Head Office, Fort', profilePhoto: null,
    createdAt: daysAgoISO(200),
  });
  for (let i = 1; i <= 5; i++) {
    users.push({
      id: uid('u'), username: 'officer' + i, password: 'Officer@1234', role: 'OFFICER',
      firstName: 'Officer' + i, lastName: 'BMC', email: 'officer' + i + '@mumbaiconnect.gov.in',
      phone: '98765400' + (10 + i), wardId: null, address: '', profilePhoto: null,
      createdAt: daysAgoISO(180),
    });
  }
  for (let i = 1; i <= 10; i++) {
    const ward = wards[Math.floor(Math.random() * wards.length)];
    users.push({
      id: uid('u'), username: 'citizen' + i, password: 'Citizen@1234', role: 'CITIZEN',
      firstName: 'Citizen' + i, lastName: 'Mumbaikar', email: 'citizen' + i + '@example.com',
      phone: '987654' + (3000 + i), wardId: ward.id, address: 'Near ' + ward.name, profilePhoto: null,
      createdAt: daysAgoISO(150 - i * 3),
    });
  }
  dbSet(DB_KEYS.USERS, users);

  // Officers (linked to officer-role users)
  const officerUsers = users.filter(u => u.role === 'OFFICER');
  const officers = officerUsers.map((u, i) => ({
    id: uid('off'), userId: u.id, employeeId: 'BMC-EMP-' + (1000 + i + 1),
    department: DEPARTMENTS[i % DEPARTMENTS.length],
    wardIds: shuffle(wards.map(w => w.id)).slice(0, 3),
    designation: 'Ward Officer', isActive: true,
  }));
  dbSet(DB_KEYS.OFFICERS, officers);

  // Complaints: ~55 realistic sample complaints
  const citizenUsers = users.filter(u => u.role === 'CITIZEN');
  const statusWeights = [15, 15, 15, 20, 25, 10]; // matches STATUSES order
  const complaints = [];
  let seq = 1;
  const total = 55;
  for (let i = 0; i < total; i++) {
    const cat = CATEGORIES[Math.floor(Math.random() * CATEGORIES.length)];
    const ward = wards[Math.floor(Math.random() * wards.length)];
    const citizen = citizenUsers[Math.floor(Math.random() * citizenUsers.length)];
    const status = weightedPick(STATUSES.map(s => s.value), statusWeights);
    const daysBack = Math.floor(Math.random() * 120);
    const createdAt = daysAgoISO(daysBack);
    const lat = ward.lat + (Math.random() - 0.5) * 0.02;
    const lng = ward.lng + (Math.random() - 0.5) * 0.02;

    const complaint = {
      id: uid('c'),
      complaintId: 'MC-2026-' + String(seq++).padStart(5, '0'),
      citizenId: citizen.id,
      category: cat.value,
      title: sampleTitle(cat.value),
      description: 'Sample auto-generated complaint for demonstration purposes in ward ' + ward.code + '.',
      wardId: ward.id,
      address: 'Near ' + ward.name + ' main road',
      lat, lng,
      status,
      priority: PRIORITIES[Math.floor(Math.random() * PRIORITIES.length)],
      assignedOfficerId: null,
      isSpam: false,
      isDuplicateOf: null,
      photos: [],
      createdAt,
      updatedAt: createdAt,
      resolvedAt: null,
      statusHistory: [{ status: 'SUBMITTED', remarks: 'Complaint submitted by citizen.', changedBy: citizen.username, changedAt: createdAt }],
    };

    if (['ASSIGNED', 'IN_PROGRESS', 'RESOLVED', 'CLOSED'].includes(status)) {
      const officer = officers[Math.floor(Math.random() * officers.length)];
      complaint.assignedOfficerId = officer.id;
      complaint.statusHistory.push({ status: 'ASSIGNED', remarks: 'Assigned to ' + officerLabel(officer, users), changedBy: 'admin', changedAt: addDaysISO(createdAt, 1) });
    }
    if (['RESOLVED', 'CLOSED'].includes(status)) {
      const resolvedAt = addDaysISO(createdAt, 2 + Math.floor(Math.random() * 12));
      complaint.resolvedAt = resolvedAt;
      complaint.statusHistory.push({ status: 'RESOLVED', remarks: 'Issue resolved by ward team.', changedBy: 'admin', changedAt: resolvedAt });
    }
    complaints.push(complaint);
  }
  dbSet(DB_KEYS.COMPLAINTS, complaints);
  dbSet(DB_KEYS.COMPLAINT_SEQ, seq);

  // Notifications (a few, tied to the most recent complaints per citizen)
  const notifications = complaints.slice(0, 20).map(c => ({
    id: uid('n'), userId: c.citizenId, complaintId: c.id,
    message: 'Your complaint ' + c.complaintId + ' is now "' + statusLabel(c.status) + '".',
    isRead: Math.random() > 0.5, createdAt: c.updatedAt,
  }));
  dbSet(DB_KEYS.NOTIFICATIONS, notifications);

  dbSet(DB_KEYS.SEEDED, true);
}

function officerLabel(officer, users) {
  const u = users.find(u => u.id === officer.userId);
  return u ? (u.firstName + ' ' + u.lastName) : 'Officer';
}

function sampleTitle(cat) {
  const map = {
    GARBAGE: 'Garbage pile not collected for days',
    POTHOLE: 'Large pothole causing traffic issues',
    SEWAGE: 'Sewage overflow on main road',
    FOOTPATH: 'Broken footpath tiles, tripping hazard',
    WATERLOGGING: 'Severe waterlogging after rain',
    STREETLIGHT: 'Streetlight not working for a week',
    ILLEGAL_DUMPING: 'Illegal construction debris dumping',
    OTHER: 'Civic issue needing attention',
  };
  return map[cat] || 'Civic issue';
}

function weightedPick(values, weights) {
  const total = weights.reduce((a, b) => a + b, 0);
  let r = Math.random() * total;
  for (let i = 0; i < values.length; i++) {
    if (r < weights[i]) return values[i];
    r -= weights[i];
  }
  return values[values.length - 1];
}

function shuffle(arr) {
  const a = arr.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function daysAgoISO(days) {
  const d = new Date();
  d.setDate(d.getDate() - days);
  return d.toISOString();
}

function addDaysISO(iso, days) {
  const d = new Date(iso);
  d.setDate(d.getDate() + days);
  return d.toISOString();
}

/* ---------------------------- Accessors ---------------------------- */

function getUsers() { return dbGet(DB_KEYS.USERS, []); }
function saveUsers(users) { return dbSet(DB_KEYS.USERS, users); }
function getUserByUsername(username) { return getUsers().find(u => u.username.toLowerCase() === String(username).toLowerCase()); }
function getUserById(id) { return getUsers().find(u => u.id === id); }

function getWards() { return dbGet(DB_KEYS.WARDS, []); }
function getWardById(id) { return getWards().find(w => w.id === id); }

function getOfficers() { return dbGet(DB_KEYS.OFFICERS, []); }
function getOfficerById(id) { return getOfficers().find(o => o.id === id); }
function saveOfficers(list) { return dbSet(DB_KEYS.OFFICERS, list); }

function getComplaints() { return dbGet(DB_KEYS.COMPLAINTS, []); }
function saveComplaints(list) { return dbSet(DB_KEYS.COMPLAINTS, list); }
function getComplaintByPublicId(complaintId) {
  return getComplaints().find(c => c.complaintId.toLowerCase() === String(complaintId).toLowerCase());
}
function getComplaintByInternalId(id) { return getComplaints().find(c => c.id === id); }

function nextComplaintId() {
  const seq = dbGet(DB_KEYS.COMPLAINT_SEQ, 1);
  dbSet(DB_KEYS.COMPLAINT_SEQ, seq + 1);
  return 'MC-2026-' + String(seq).padStart(5, '0');
}

function createComplaint(data) {
  const complaints = getComplaints();
  const now = new Date().toISOString();
  const complaint = Object.assign({
    id: uid('c'),
    complaintId: nextComplaintId(),
    status: 'SUBMITTED',
    priority: 'MEDIUM',
    assignedOfficerId: null,
    isSpam: false,
    isDuplicateOf: null,
    photos: [],
    createdAt: now,
    updatedAt: now,
    resolvedAt: null,
    statusHistory: [{ status: 'SUBMITTED', remarks: 'Complaint submitted by citizen.', changedBy: data.citizenUsername || 'citizen', changedAt: now }],
  }, data);
  complaints.unshift(complaint);
  saveComplaints(complaints);
  return complaint;
}

function updateComplaint(id, patch) {
  const complaints = getComplaints();
  const idx = complaints.findIndex(c => c.id === id);
  if (idx === -1) return null;
  complaints[idx] = Object.assign({}, complaints[idx], patch, { updatedAt: new Date().toISOString() });
  saveComplaints(complaints);
  return complaints[idx];
}

function deleteComplaint(id) {
  saveComplaints(getComplaints().filter(c => c.id !== id));
}

function getNotifications() { return dbGet(DB_KEYS.NOTIFICATIONS, []); }
function saveNotifications(list) { return dbSet(DB_KEYS.NOTIFICATIONS, list); }
function getNotificationsForUser(userId) {
  return getNotifications().filter(n => n.userId === userId).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
}
function createNotification(userId, complaintId, message) {
  const list = getNotifications();
  list.unshift({ id: uid('n'), userId, complaintId, message, isRead: false, createdAt: new Date().toISOString() });
  saveNotifications(list);
}
function markAllNotificationsRead(userId) {
  const list = getNotifications().map(n => n.userId === userId ? Object.assign({}, n, { isRead: true }) : n);
  saveNotifications(list);
}

/* ---------------------------- Domain helpers ---------------------------- */

function categoryMeta(value) { return CATEGORIES.find(c => c.value === value) || CATEGORIES[CATEGORIES.length - 1]; }
function statusMeta(value) { return STATUSES.find(s => s.value === value) || STATUSES[0]; }
function statusLabel(value) { return statusMeta(value).label; }
function statusProgressPct(value) { return statusMeta(value).pct; }

function haversineMeters(lat1, lon1, lat2, lon2) {
  const R = 6371000;
  const toRad = d => d * Math.PI / 180;
  const dphi = toRad(lat2 - lat1);
  const dlambda = toRad(lon2 - lon1);
  const a = Math.sin(dphi / 2) ** 2 + Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dlambda / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

function findPossibleDuplicates(category, lat, lng, excludeId) {
  if (lat == null || lng == null) return [];
  const cutoff = Date.now() - DUPLICATE_WINDOW_DAYS * 86400000;
  return getComplaints().filter(c => {
    if (c.id === excludeId) return false;
    if (c.category !== category) return false;
    if (new Date(c.createdAt).getTime() < cutoff) return false;
    if (c.lat == null || c.lng == null) return false;
    return haversineMeters(lat, lng, c.lat, c.lng) <= DUPLICATE_RADIUS_METERS;
  });
}

function formatDate(iso, withTime) {
  if (!iso) return '—';
  const d = new Date(iso);
  const dateStr = d.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });
  if (!withTime) return dateStr;
  const timeStr = d.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  return dateStr + ', ' + timeStr;
}

function timeAgo(iso) {
  const diff = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diff / 60000);
  if (mins < 1) return 'just now';
  if (mins < 60) return mins + 'm ago';
  const hrs = Math.floor(mins / 60);
  if (hrs < 24) return hrs + 'h ago';
  const days = Math.floor(hrs / 24);
  return days + 'd ago';
}
