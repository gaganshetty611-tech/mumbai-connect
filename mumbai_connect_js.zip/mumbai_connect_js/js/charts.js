/* =========================================================================
   MUMBAI CONNECT — Chart rendering (charts.js)
   ========================================================================= */

const CHART_PALETTE = ['#114B9C', '#16814F', '#C97A22', '#B23A48', '#6B5CA5', '#1E7FB8', '#B8860B', '#55617A'];

function renderWardChart(canvasId, wardCounts) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: wardCounts.map(w => w.code),
      datasets: [{ label: 'Complaints', data: wardCounts.map(w => w.count), backgroundColor: '#114B9C', borderRadius: 6 }],
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false }, title: { display: true, text: 'Ward-wise Complaints' } },
      scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
    },
  });
}

function renderCategoryChart(canvasId, categoryCounts) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  new Chart(ctx, {
    type: 'doughnut',
    data: {
      labels: categoryCounts.map(c => categoryMeta(c.category).label),
      datasets: [{ data: categoryCounts.map(c => c.count), backgroundColor: CHART_PALETTE }],
    },
    options: {
      responsive: true,
      plugins: { legend: { position: 'bottom' }, title: { display: true, text: 'Category-wise Distribution' } },
    },
  });
}

function renderTrendChart(canvasId, monthlyCounts) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  new Chart(ctx, {
    type: 'line',
    data: {
      labels: monthlyCounts.map(m => m.label),
      datasets: [{
        label: 'Complaints per Month', data: monthlyCounts.map(m => m.count), borderColor: '#16814F',
        backgroundColor: 'rgba(22,129,79,0.12)', tension: 0.35, fill: true, pointRadius: 4,
      }],
    },
    options: {
      responsive: true,
      plugins: { legend: { display: false }, title: { display: true, text: 'Monthly Complaint Trends' } },
      scales: { y: { beginAtZero: true, ticks: { precision: 0 } } },
    },
  });
}

function renderStatusChart(canvasId, statusCounts) {
  const ctx = document.getElementById(canvasId);
  if (!ctx) return;
  new Chart(ctx, {
    type: 'pie',
    data: {
      labels: statusCounts.map(s => statusLabel(s.status)),
      datasets: [{ data: statusCounts.map(s => s.count), backgroundColor: CHART_PALETTE }],
    },
    options: { responsive: true, plugins: { legend: { position: 'bottom' }, title: { display: true, text: 'Status Breakdown' } } },
  });
}

/* ---------------------------- Aggregation helpers ---------------------------- */

function aggregateByWard(complaints) {
  const wards = getWards();
  return wards.map(w => ({ code: w.code, count: complaints.filter(c => c.wardId === w.id).length }))
    .filter(w => w.count > 0)
    .sort((a, b) => b.count - a.count);
}

function aggregateByCategory(complaints) {
  const counts = {};
  complaints.forEach(c => { counts[c.category] = (counts[c.category] || 0) + 1; });
  return Object.entries(counts).map(([category, count]) => ({ category, count })).sort((a, b) => b.count - a.count);
}

function aggregateByStatus(complaints) {
  const counts = {};
  complaints.forEach(c => { counts[c.status] = (counts[c.status] || 0) + 1; });
  return STATUSES.map(s => ({ status: s.value, count: counts[s.value] || 0 })).filter(s => s.count > 0);
}

function aggregateByMonth(complaints) {
  const counts = {};
  complaints.forEach(c => {
    const d = new Date(c.createdAt);
    const key = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0');
    counts[key] = (counts[key] || 0) + 1;
  });
  return Object.keys(counts).sort().map(key => {
    const [y, m] = key.split('-');
    const label = new Date(y, m - 1, 1).toLocaleDateString('en-IN', { month: 'short', year: 'numeric' });
    return { key, label, count: counts[key] };
  });
}

function averageResolutionDays(complaints) {
  const resolved = complaints.filter(c => c.resolvedAt);
  if (!resolved.length) return null;
  const totalDays = resolved.reduce((sum, c) => sum + (new Date(c.resolvedAt) - new Date(c.createdAt)) / 86400000, 0);
  return Math.round((totalDays / resolved.length) * 10) / 10;
}
