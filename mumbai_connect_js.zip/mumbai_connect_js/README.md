# 🏙️ Mumbai Connect — Smart Civic Complaint Management System
### (JavaScript edition — zero install, zero terminal, zero server)

A premium, responsive civic complaint portal for Mumbai citizens — garbage, potholes, sewage, waterlogging, streetlights, and more — with photo uploads, GPS/map location, a status timeline, and a full admin dashboard with charts and a hotspot heatmap.

This version runs **entirely in your browser**. There is no Python, no Django, no MySQL, no npm, no terminal commands of any kind. If you've been fighting with the Django/venv/migrations version, this is the "it just works" alternative.

---

## 🚀 How to run it (this is the entire process)

1. Unzip the folder.
2. Double-click **`index.html`**.
3. That's it. Your browser opens the site.

No installation. No server. No command line. If step 2 doesn't open it automatically, right-click `index.html` → **Open with** → choose any browser (Chrome, Edge, Firefox).

> The only thing you need is an internet connection the **first time** you open it — a few visual libraries (Bootstrap, Leaflet maps, Chart.js) load from a CDN, exactly like any normal website. Once loaded, everything else (your data, your login, your complaints) works fully offline from your browser's local storage.

**Demo logins** (auto-created the first time you open the site):
| Role    | Username  | Password       |
|---------|-----------|----------------|
| Admin   | admin     | Admin@1234     |
| Officer | officer1  | Officer@1234   |
| Citizen | citizen1  | Citizen@1234   |

---

## ✨ What's included and working

**Citizens**
- Registration & login, editable profile with photo
- Submit complaints: category, description, up to 3 photos (with live preview), GPS auto-detect or click-to-pin on an OpenStreetMap map, ward selection
- Automatic duplicate-complaint warning (same category + nearby location + within 7 days)
- Complaint history with search, filters, and pagination
- Public "Track by Complaint ID" — no login needed
- Visual status timeline: Submitted → Under Review → Assigned → In Progress → Resolved → Closed
- In-app notifications on every status change

**Admin / Officer Dashboard**
- KPI widgets: total users, total complaints, pending, resolved
- Ward-wise bar chart, category-wise doughnut chart, monthly trend line chart, status pie chart (Chart.js)
- Complaint hotspot heatmap (Leaflet)
- Search, filter, and paginate all complaints
- View photo evidence, update status with remarks (full audit trail), assign to an officer, mark spam, delete
- Downloadable PDF summary report

**Design**
- Civic Blue / White / Growth Green theme with a monospace "data" treatment for IDs, stats, and timestamps
- Custom Mumbai skyline illustration (Gateway of India, BEST bus, Bandra-Worli Sea Link) in the hero
- A live "civic pulse" ticker showing recent complaint activity
- Dark/light mode toggle (persisted), fully responsive, hover cards, category icons
- Accessibility: skip-to-content link, visible keyboard focus, respects reduced-motion, alt text throughout

---

## 📁 File structure

```
mumbai_connect_js/
├── index.html                 Home (hero, stats, categories)
├── about.html
├── contact.html
├── faq.html
├── signup.html
├── login.html
├── dashboard.html             Citizen dashboard
├── submit-complaint.html      Photo upload, GPS, map picker, duplicate check
├── complaint-detail.html      Timeline + photos + map; also the admin "manage" view
├── complaint-history.html     Citizen's own complaints (search/filter/pagination)
├── track-complaint.html       Public tracker, no login
├── profile.html
├── notifications.html
├── admin-dashboard.html       Staff KPIs
├── admin-complaints.html      Full complaint list for staff (search/filter/pagination)
├── admin-analytics.html       Charts, heatmap, resolution stats, PDF export
├── css/
│   └── style.css              Design tokens + all components
└── js/
    ├── db.js                  "Database": localStorage + seed data + CRUD
    ├── auth.js                Login/signup/logout/session/route guards
    ├── ui.js                  Navbar/footer rendering, theme toggle, toasts, pagination
    ├── map.js                 Leaflet location picker / static map / heatmap
    ├── charts.js              Chart.js rendering + aggregation helpers
    └── pdf.js                 PDF report export (jsPDF)
```

Every page is a plain `.html` file you can open directly — there's no build step, bundler, or framework compilation involved.

---

## 🗄️ How data storage works (read this before using it for anything real)

This build stores everything — users, complaints, wards, officers, notifications — in your **browser's localStorage**, seeded automatically the first time you open the site. That means:

- **Data is per-browser, per-device.** What you submit in Chrome won't show up in Firefox, or on your phone, or for someone else opening the same file on their own computer.
- **Passwords are stored in plain text** in your browser for this demo. That is fine for a portfolio/classroom project, but this is *not* how real authentication should ever work — a real deployment needs a real backend that hashes passwords and manages sessions server-side.
- **Storage has a size limit** (typically 5–10MB per browser). Photos are automatically compressed before saving, but if you upload a lot of complaints with photos, you can hit the limit. There's a **"Reset demo data"** link in the footer of every page that wipes local data and reloads a fresh seed if that happens.
- **"Email alerts"** are simulated as in-app notifications (see the bell icon) since a static site has no mail server to actually send email from.

None of this is a bug — it's the trade-off that makes the site runnable with zero setup. If you need a real multi-user backend with a real database (for an actual production deployment, not just a demo/portfolio piece), that requires a server — see the note below.

---

## 🧩 Want a real backend instead?

If this is for a class project or portfolio and the zero-install version above is all you need, you're done. If you specifically need a real server + database (e.g., MySQL) version with Django — for example because an assignment requires showing backend code, models, migrations, etc. — that's a materially different deliverable (it needs Python installed, a virtual environment, and terminal commands to run). Just ask and it can be provided separately; it's a good idea to keep the two versions in separate folders so they don't get mixed up.

---

## 🔧 Customizing

- **Colors/fonts**: all design tokens are CSS variables at the top of `css/style.css` (`:root` and `[data-theme="dark"]`).
- **Wards, categories, statuses, emergency numbers**: edit the constant arrays at the top of `js/db.js`.
- **Seed data volume**: change the `total` variable inside `seedIfNeeded()` in `js/db.js` (currently 55 sample complaints).
- **Map provider**: `js/map.js` uses OpenStreetMap tiles (no API key needed). To use Google Maps instead, you'd swap the Leaflet tile layer for the Google Maps JavaScript API, which does require an API key/billing account.

---

## 📌 Honest scope notes

Everything listed in "What's included and working" above is real and functional — not a mockup. Two things are intentionally simplified given this is a front-end-only build, both explained above: authentication is demo-grade (not production security), and "email" alerts are in-app rather than real email delivery. Everything else — the full complaint lifecycle, admin tools, analytics, maps, PDF export, dark mode, search/pagination — works as described.
