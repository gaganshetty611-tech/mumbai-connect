from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib.auth.views import LoginView
from django.contrib import messages
from django.shortcuts import render, redirect
from django.urls import reverse_lazy

from .forms import SignUpForm, LoginForm, ProfileUpdateForm
from complaints.models import Complaint


def signup_view(request):
    if request.user.is_authenticated:
        return redirect('complaints:user_dashboard')

    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, f"Welcome to Mumbai Connect, {user.first_name}! Your account has been created.")
            return redirect('complaints:user_dashboard')
        messages.error(request, "Please correct the errors below.")
    else:
        form = SignUpForm()
    return render(request, 'accounts/signup.html', {'form': form})


class CustomLoginView(LoginView):
    template_name = 'accounts/login.html'
    authentication_form = LoginForm
    redirect_authenticated_user = True

    def form_valid(self, form):
        messages.success(self.request, f"Welcome back, {form.get_user().first_name or form.get_user().username}!")
        return super().form_valid(form)

    def get_success_url(self):
        user = self.request.user
        if user.is_admin_role or user.is_officer_role:
            return reverse_lazy('admin_panel:dashboard')
        return reverse_lazy('complaints:user_dashboard')


def logout_view(request):
    logout(request)
    messages.info(request, "You have been logged out successfully.")
    return redirect('core:home')


@login_required
def profile_view(request):
    if request.method == 'POST':
        form = ProfileUpdateForm(request.POST, request.FILES, instance=request.user)
        if form.is_valid():
            form.save()
            messages.success(request, "Profile updated successfully.")
            return redirect('accounts:profile')
    else:
        form = ProfileUpdateForm(instance=request.user)

    recent_complaints = Complaint.objects.filter(citizen=request.user).order_by('-created_at')[:5]
    stats = {
        'total': Complaint.objects.filter(citizen=request.user).count(),
        'resolved': Complaint.objects.filter(citizen=request.user, status='RESOLVED').count(),
        'pending': Complaint.objects.filter(citizen=request.user).exclude(status__in=['RESOLVED', 'CLOSED']).count(),
    }
    return render(request, 'accounts/profile.html', {
        'form': form, 'recent_complaints': recent_complaints, 'stats': stats,
    })
