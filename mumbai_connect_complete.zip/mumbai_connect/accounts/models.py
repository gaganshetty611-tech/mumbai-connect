from django.contrib.auth.models import AbstractUser
from django.db import models
from wards.models import Ward


class User(AbstractUser):
    """
    Custom user model. Extends Django's built-in auth user with
    civic-portal specific fields. `role` distinguishes citizens from
    municipal officers/admins for permission checks across the app.
    """

    class Role(models.TextChoices):
        CITIZEN = 'CITIZEN', 'Citizen'
        OFFICER = 'OFFICER', 'Ward Officer'
        ADMIN = 'ADMIN', 'Administrator'

    role = models.CharField(max_length=10, choices=Role.choices, default=Role.CITIZEN)
    phone_number = models.CharField(max_length=15, blank=True)
    address = models.CharField(max_length=255, blank=True)
    ward = models.ForeignKey(Ward, on_delete=models.SET_NULL, null=True, blank=True, related_name='residents')
    profile_photo = models.ImageField(upload_to='profile_photos/', null=True, blank=True)
    is_verified = models.BooleanField(default=False)
    created_at = models.DateTimeField(auto_now_add=True)

    @property
    def is_admin_role(self):
        return self.role == self.Role.ADMIN or self.is_superuser

    @property
    def is_officer_role(self):
        return self.role == self.Role.OFFICER

    def __str__(self):
        return self.get_full_name() or self.username
