from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User


@admin.register(User)
class CustomUserAdmin(UserAdmin):
    list_display = ('username', 'email', 'first_name', 'last_name', 'role', 'ward', 'is_verified', 'is_staff')
    list_filter = ('role', 'ward', 'is_verified', 'is_staff')
    fieldsets = UserAdmin.fieldsets + (
        ('Civic Profile', {'fields': ('role', 'phone_number', 'address', 'ward', 'profile_photo', 'is_verified')}),
    )
