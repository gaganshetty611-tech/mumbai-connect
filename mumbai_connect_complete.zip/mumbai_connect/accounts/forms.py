from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import User
from wards.models import Ward


class SignUpForm(UserCreationForm):
    """Citizen registration form with civic-profile fields."""
    first_name = forms.CharField(max_length=100, required=True,
                                  widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'First name'}))
    last_name = forms.CharField(max_length=100, required=True,
                                 widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Last name'}))
    email = forms.EmailField(required=True,
                              widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'you@example.com'}))
    phone_number = forms.CharField(max_length=15, required=True,
                                    widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': '10-digit mobile number'}))
    ward = forms.ModelChoiceField(queryset=Ward.objects.all(), required=False, empty_label="Select your ward (optional)",
                                   widget=forms.Select(attrs={'class': 'form-select'}))
    address = forms.CharField(required=False, widget=forms.Textarea(
        attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Street / building / area'}))

    class Meta:
        model = User
        fields = ('username', 'first_name', 'last_name', 'email', 'phone_number',
                  'ward', 'address', 'password1', 'password2')

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['username'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Choose a username'})
        self.fields['password1'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Password'})
        self.fields['password2'].widget.attrs.update({'class': 'form-control', 'placeholder': 'Confirm password'})

    def clean_phone_number(self):
        phone = self.cleaned_data['phone_number']
        digits = ''.join(filter(str.isdigit, phone))
        if len(digits) != 10:
            raise forms.ValidationError("Enter a valid 10-digit mobile number.")
        return digits

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.phone_number = self.cleaned_data['phone_number']
        user.ward = self.cleaned_data.get('ward')
        user.address = self.cleaned_data.get('address', '')
        user.role = User.Role.CITIZEN
        if commit:
            user.save()
        return user


class LoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(
        attrs={'class': 'form-control', 'placeholder': 'Username', 'autofocus': True}))
    password = forms.CharField(widget=forms.PasswordInput(
        attrs={'class': 'form-control', 'placeholder': 'Password'}))


class ProfileUpdateForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email', 'phone_number', 'address', 'ward', 'profile_photo')
        widgets = {
            'first_name': forms.TextInput(attrs={'class': 'form-control'}),
            'last_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'phone_number': forms.TextInput(attrs={'class': 'form-control'}),
            'address': forms.Textarea(attrs={'class': 'form-control', 'rows': 2}),
            'ward': forms.Select(attrs={'class': 'form-select'}),
            'profile_photo': forms.ClearableFileInput(attrs={'class': 'form-control'}),
        }
