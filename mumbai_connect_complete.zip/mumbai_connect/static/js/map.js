// Mumbai Connect — Interactive map for complaint location selection
// Uses Leaflet.js + OpenStreetMap tiles (no API key required).

document.addEventListener('DOMContentLoaded', function () {
  const mapContainer = document.getElementById('location-map');
  if (!mapContainer || typeof L === 'undefined') return;

  const latField = document.getElementById('id_latitude');
  const lngField = document.getElementById('id_longitude');
  const gpsStatus = document.getElementById('gps-status');

  // Default center: Mumbai (CST / VT)
  const defaultLat = 19.0760;
  const defaultLng = 72.8777;

  const map = L.map('location-map').setView([defaultLat, defaultLng], 11);

  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; OpenStreetMap contributors',
  }).addTo(map);

  let marker = null;

  function setMarker(lat, lng) {
    if (marker) {
      marker.setLatLng([lat, lng]);
    } else {
      marker = L.marker([lat, lng], { draggable: true }).addTo(map);
      marker.on('dragend', function (e) {
        const pos = marker.getLatLng();
        updateFields(pos.lat, pos.lng);
      });
    }
    map.panTo([lat, lng]);
  }

  function updateFields(lat, lng) {
    latField.value = lat;
    lngField.value = lng;
    if (gpsStatus) {
      gpsStatus.textContent = `Selected location: ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
      gpsStatus.className = 'text-success small mt-2';
    }
  }

  map.on('click', function (e) {
    setMarker(e.latlng.lat, e.latlng.lng);
    updateFields(e.latlng.lat, e.latlng.lng);
  });

  // Exposed so preview.js (GPS button) can move the marker too
  window.mcSetMapMarker = function (lat, lng) {
    setMarker(lat, lng);
    updateFields(lat, lng);
  };

  // If editing / re-rendering with existing coordinates
  if (latField.value && lngField.value) {
    setMarker(parseFloat(latField.value), parseFloat(lngField.value));
  }
});
