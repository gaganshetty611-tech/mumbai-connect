// Mumbai Connect — complaint submission helpers:
// 1. Live image preview for multiple uploaded photos
// 2. Browser GPS geolocation detection

document.addEventListener('DOMContentLoaded', function () {
  const photoInput = document.querySelector('input[name="photos"]');
  const previewGrid = document.getElementById('photo-preview-grid');

  if (photoInput && previewGrid) {
    photoInput.addEventListener('change', function (e) {
      previewGrid.innerHTML = '';
      const files = Array.from(e.target.files).slice(0, 5);

      if (e.target.files.length > 5) {
        showFieldWarning('Only the first 5 photos will be uploaded.');
      }

      files.forEach(function (file) {
        if (!file.type.startsWith('image/')) return;
        const reader = new FileReader();
        reader.onload = function (evt) {
          const item = document.createElement('div');
          item.className = 'preview-item';
          item.innerHTML = `<img src="${evt.target.result}" alt="Preview">`;
          previewGrid.appendChild(item);
        };
        reader.readAsDataURL(file);
      });
    });
  }

  function showFieldWarning(msg) {
    let warn = document.getElementById('photo-warning');
    if (!warn) {
      warn = document.createElement('div');
      warn.id = 'photo-warning';
      warn.className = 'text-warning small mt-1';
      previewGrid.parentNode.insertBefore(warn, previewGrid);
    }
    warn.textContent = msg;
  }

  // ---------------- GPS Detection ----------------
  const gpsBtn = document.getElementById('detect-location-btn');
  const latField = document.getElementById('id_latitude');
  const lngField = document.getElementById('id_longitude');
  const gpsStatus = document.getElementById('gps-status');

  if (gpsBtn) {
    gpsBtn.addEventListener('click', function () {
      if (!navigator.geolocation) {
        gpsStatus.textContent = 'Geolocation is not supported by your browser.';
        gpsStatus.className = 'text-danger small mt-2';
        return;
      }
      gpsStatus.textContent = 'Detecting your location...';
      gpsStatus.className = 'text-muted small mt-2';

      navigator.geolocation.getCurrentPosition(function (position) {
        const lat = position.coords.latitude;
        const lng = position.coords.longitude;
        latField.value = lat;
        lngField.value = lng;
        gpsStatus.textContent = `Location detected: ${lat.toFixed(5)}, ${lng.toFixed(5)}`;
        gpsStatus.className = 'text-success small mt-2';
        if (window.mcSetMapMarker) window.mcSetMapMarker(lat, lng);
      }, function (error) {
        gpsStatus.textContent = 'Could not detect location. Please select it on the map instead.';
        gpsStatus.className = 'text-danger small mt-2';
      });
    });
  }
});
