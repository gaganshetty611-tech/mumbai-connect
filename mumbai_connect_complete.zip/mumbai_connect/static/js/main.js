// Mumbai Connect — global JS (theme toggle, page loader, small UX helpers)

(function () {
  const THEME_KEY = 'mc-theme';

  function applyTheme(theme) {
    document.documentElement.setAttribute('data-theme', theme);
    const icon = document.getElementById('theme-icon');
    if (icon) {
      icon.className = theme === 'dark' ? 'bi bi-sun-fill' : 'bi bi-moon-stars-fill';
    }
  }

  function initTheme() {
    const saved = localStorage.getItem(THEME_KEY) ||
      (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
    applyTheme(saved);
  }

  window.toggleTheme = function () {
    const current = document.documentElement.getAttribute('data-theme') || 'light';
    const next = current === 'dark' ? 'light' : 'dark';
    localStorage.setItem(THEME_KEY, next);
    applyTheme(next);
  };

  document.addEventListener('DOMContentLoaded', function () {
    initTheme();

    // Fade in page content (simple loading animation)
    document.body.classList.add('mc-loaded');

    // Auto-dismiss alerts after 5s
    document.querySelectorAll('.alert.auto-dismiss').forEach(function (el) {
      setTimeout(function () {
        const alert = bootstrap.Alert.getOrCreateInstance(el);
        alert.close();
      }, 5000);
    });

    // Enable Bootstrap tooltips
    document.querySelectorAll('[data-bs-toggle="tooltip"]').forEach(function (el) {
      new bootstrap.Tooltip(el);
    });
  });
})();
