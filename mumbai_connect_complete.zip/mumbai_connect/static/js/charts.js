// Mumbai Connect — Chart.js analytics rendering
// Reads data from data-* attributes on #chart-data (JSON injected by Django templates)

document.addEventListener('DOMContentLoaded', function () {
  const dataEl = document.getElementById('chart-data');
  if (!dataEl || typeof Chart === 'undefined') return;

  const wardLabels = JSON.parse(dataEl.dataset.wardLabels || '[]');
  const wardCounts = JSON.parse(dataEl.dataset.wardCounts || '[]');
  const categoryLabels = JSON.parse(dataEl.dataset.categoryLabels || '[]');
  const categoryCounts = JSON.parse(dataEl.dataset.categoryCounts || '[]');
  const trendLabels = JSON.parse(dataEl.dataset.trendLabels || '[]');
  const trendCounts = JSON.parse(dataEl.dataset.trendCounts || '[]');

  const palette = ['#0b3d91', '#1a8f4c', '#e08a1a', '#d64545', '#6f42c1', '#17a2b8', '#c2185b', '#6c757d'];

  const wardCtx = document.getElementById('wardChart');
  if (wardCtx) {
    new Chart(wardCtx, {
      type: 'bar',
      data: {
        labels: wardLabels,
        datasets: [{ label: 'Complaints', data: wardCounts, backgroundColor: '#0b3d91', borderRadius: 6 }],
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false }, title: { display: true, text: 'Ward-wise Complaints' } },
        scales: { y: { beginAtZero: true } },
      },
    });
  }

  const categoryCtx = document.getElementById('categoryChart');
  if (categoryCtx) {
    new Chart(categoryCtx, {
      type: 'doughnut',
      data: {
        labels: categoryLabels,
        datasets: [{ data: categoryCounts, backgroundColor: palette }],
      },
      options: {
        responsive: true,
        plugins: { legend: { position: 'bottom' }, title: { display: true, text: 'Category-wise Distribution' } },
      },
    });
  }

  const trendCtx = document.getElementById('trendChart');
  if (trendCtx) {
    new Chart(trendCtx, {
      type: 'line',
      data: {
        labels: trendLabels,
        datasets: [{
          label: 'Complaints per Month', data: trendCounts, borderColor: '#1a8f4c',
          backgroundColor: 'rgba(26,143,76,0.12)', tension: 0.35, fill: true, pointRadius: 4,
        }],
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false }, title: { display: true, text: 'Monthly Complaint Trends' } },
        scales: { y: { beginAtZero: true } },
      },
    });
  }
});
