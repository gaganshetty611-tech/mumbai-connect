from django.db import migrations, models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
    ]

    operations = [
        migrations.CreateModel(
            name='Ward',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('code', models.CharField(help_text="BMC ward code, e.g. 'A', 'K/E'", max_length=5, unique=True)),
                ('name', models.CharField(help_text="Area name, e.g. 'Colaba / Fort'", max_length=100)),
                ('zone', models.CharField(blank=True, help_text='City / Western / Eastern suburbs', max_length=50)),
                ('latitude', models.FloatField(default=19.076)),
                ('longitude', models.FloatField(default=72.8777)),
            ],
            options={
                'ordering': ['code'],
            },
        ),
    ]
