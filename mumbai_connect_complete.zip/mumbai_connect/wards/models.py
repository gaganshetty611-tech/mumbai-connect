from django.db import models


class Ward(models.Model):
    """
    Represents one of the 24 administrative wards of the Brihanmumbai
    Municipal Corporation (BMC). Used to route/group complaints.
    """
    code = models.CharField(max_length=5, unique=True, help_text="BMC ward code, e.g. 'A', 'K/E'")
    name = models.CharField(max_length=100, help_text="Area name, e.g. 'Colaba / Fort'")
    zone = models.CharField(max_length=50, blank=True, help_text="City / Western / Eastern suburbs")
    latitude = models.FloatField(default=19.0760)
    longitude = models.FloatField(default=72.8777)

    class Meta:
        ordering = ['code']

    def __str__(self):
        return f"{self.code} — {self.name}"
