from django.contrib import admin
from .models import Ward


@admin.register(Ward)
class WardAdmin(admin.ModelAdmin):
    list_display = ('code', 'name', 'zone', 'latitude', 'longitude')
    search_fields = ('code', 'name', 'zone')
    ordering = ('code',)
