"""
Management command to populate the database with sample/demo data:
- All 24 BMC wards of Mumbai
- A superuser (admin), a couple of ward officers, and demo citizens
- A realistic spread of sample complaints across categories/statuses

Usage:
    python manage.py seed_data
"""
import random
from datetime import timedelta

from django.core.management.base import BaseCommand
from django.utils import timezone

from wards.models import Ward
from accounts.models import User
from officers.models import Officer
from complaints.models import Complaint, ComplaintStatusHistory

MUMBAI_WARDS = [
    ("A", "Colaba, Fort, Churchgate", "City", 18.9218, 72.8331),
    ("B", "Dongri, Mandvi", "City", 18.9547, 72.8352),
    ("C", "Marine Lines, Kalbadevi", "City", 18.9469, 72.8258),
    ("D", "Malabar Hill, Grant Road", "City", 18.9548, 72.8090),
    ("E", "Byculla, Mazgaon", "City", 18.9750, 72.8347),
    ("F/N", "Matunga, Sion", "City", 19.0332, 72.8560),
    ("F/S", "Parel, Lower Parel", "City", 19.0018, 72.8339),
    ("G/N", "Dadar, Dharavi", "City", 19.0176, 72.8562),
    ("G/S", "Worli, Elphinstone", "City", 19.0096, 72.8175),
    ("H/E", "Bandra East, Khar East", "Western Suburbs", 19.0596, 72.8656),
    ("H/W", "Bandra West, Khar West", "Western Suburbs", 19.0596, 72.8295),
    ("K/E", "Andheri East, Jogeshwari East", "Western Suburbs", 19.1136, 72.8697),
    ("K/W", "Andheri West, Versova", "Western Suburbs", 19.1197, 72.8464),
    ("P/N", "Malad", "Western Suburbs", 19.1874, 72.8484),
    ("P/S", "Goregaon", "Western Suburbs", 19.1663, 72.8526),
    ("R/C", "Borivali", "Western Suburbs", 19.2307, 72.8567),
    ("R/N", "Dahisar", "Western Suburbs", 19.2540, 72.8590),
    ("R/S", "Kandivali", "Western Suburbs", 19.2094, 72.8526),
    ("L", "Kurla", "Eastern Suburbs", 19.0728, 72.8826),
    ("M/E", "Chembur East, Mankhurd", "Eastern Suburbs", 19.0483, 72.9186),
    ("M/W", "Chembur West", "Eastern Suburbs", 19.0522, 72.9005),
    ("N", "Ghatkopar", "Eastern Suburbs", 19.0864, 72.9082),
    ("S", "Bhandup, Powai", "Eastern Suburbs", 19.1197, 72.9051),
    ("T", "Mulund", "Eastern Suburbs", 19.1726, 72.9425),
]

CATEGORIES = [c[0] for c in Complaint.Category.choices]
STATUSES = [s[0] for s in Complaint.Status.choices]

SAMPLE_TITLES = {
    'GARBAGE': "Garbage pile not collected for days",
    'POTHOLE': "Large pothole causing traffic issues",
    'SEWAGE': "Sewage overflow on main road",
    'FOOTPATH': "Broken footpath tiles, tripping hazard",
    'WATERLOGGING': "Severe waterlogging after rain",
    'STREETLIGHT': "Streetlight not working for a week",
    'ILLEGAL_DUMPING': "Illegal construction debris dumping",
    'OTHER': "Civic issue needing attention",
}


class Command(BaseCommand):
    help = "Seed the database with Mumbai wards, sample users, and demo complaints."

    def add_arguments(self, parser):
        parser.add_argument('--complaints', type=int, default=60, help="Number of sample complaints to create")

    def handle(self, *args, **options):
        self.stdout.write(self.style.WARNING("Seeding Mumbai Connect demo data..."))

        # 1. Wards
        ward_objs = []
        for code, name, zone, lat, lng in MUMBAI_WARDS:
            ward, _ = Ward.objects.get_or_create(
                code=code, defaults={'name': name, 'zone': zone, 'latitude': lat, 'longitude': lng}
            )
            ward_objs.append(ward)
        self.stdout.write(self.style.SUCCESS(f"  ✓ {len(ward_objs)} wards ready"))

        # 2. Superuser / admin
        if not User.objects.filter(username='admin').exists():
            User.objects.create_superuser(
                username='admin', email='admin@mumbaiconnect.gov.in', password='Admin@1234',
                first_name='System', last_name='Administrator', role=User.Role.ADMIN,
            )
            self.stdout.write(self.style.SUCCESS("  ✓ Admin user created (admin / Admin@1234)"))

        # 3. Officers
        departments = [d[0] for d in Officer.Department.choices]
        officer_objs = []
        for i in range(1, 6):
            username = f"officer{i}"
            user, created = User.objects.get_or_create(
                username=username, defaults={
                    'email': f"{username}@mumbaiconnect.gov.in", 'first_name': f"Officer{i}",
                    'last_name': "BMC", 'role': User.Role.OFFICER,
                })
            if created:
                user.set_password('Officer@1234')
                user.save()
            officer, _ = Officer.objects.get_or_create(
                user=user, defaults={
                    'employee_id': f"BMC-EMP-{1000 + i}",
                    'department': random.choice(departments),
                })
            officer.wards.set(random.sample(ward_objs, 3))
            officer_objs.append(officer)
        self.stdout.write(self.style.SUCCESS(f"  ✓ {len(officer_objs)} ward officers ready (officer1..5 / Officer@1234)"))

        # 4. Citizens
        citizen_objs = []
        for i in range(1, 11):
            username = f"citizen{i}"
            user, created = User.objects.get_or_create(
                username=username, defaults={
                    'email': f"{username}@example.com", 'first_name': f"Citizen{i}",
                    'last_name': "Mumbaikar", 'role': User.Role.CITIZEN,
                    'phone_number': f"98765{40000+i}", 'ward': random.choice(ward_objs),
                })
            if created:
                user.set_password('Citizen@1234')
                user.save()
            citizen_objs.append(user)
        self.stdout.write(self.style.SUCCESS(f"  ✓ {len(citizen_objs)} demo citizens ready (citizen1..10 / Citizen@1234)"))

        # 5. Complaints
        n = options['complaints']
        created_count = 0
        for i in range(n):
            category = random.choice(CATEGORIES)
            ward = random.choice(ward_objs)
            citizen = random.choice(citizen_objs)
            status = random.choices(STATUSES, weights=[15, 15, 15, 20, 25, 10])[0]
            days_ago = random.randint(0, 120)
            created_at = timezone.now() - timedelta(days=days_ago)

            complaint = Complaint(
                citizen=citizen,
                category=category,
                title=SAMPLE_TITLES.get(category, "Civic issue"),
                description=f"Sample auto-generated complaint #{i+1} for demonstration purposes in ward {ward.code}.",
                ward=ward,
                address=f"Near {ward.name} main road",
                latitude=ward.latitude + random.uniform(-0.01, 0.01),
                longitude=ward.longitude + random.uniform(-0.01, 0.01),
                status=status,
                priority=random.choice([p[0] for p in Complaint.Priority.choices]),
            )
            if status in ['ASSIGNED', 'IN_PROGRESS', 'RESOLVED', 'CLOSED']:
                complaint.assigned_officer = random.choice(officer_objs)
            if status in ['RESOLVED', 'CLOSED']:
                complaint.resolved_at = created_at + timedelta(days=random.randint(1, 15))

            complaint.save()
            # Backdate created_at (save() sets auto_now_add, so update directly)
            Complaint.objects.filter(pk=complaint.pk).update(created_at=created_at)

            ComplaintStatusHistory.objects.create(
                complaint=complaint, status=Complaint.Status.SUBMITTED,
                remarks="Complaint submitted (seed data).", changed_by=citizen,
            )
            if complaint.status != Complaint.Status.SUBMITTED:
                ComplaintStatusHistory.objects.create(
                    complaint=complaint, status=complaint.status,
                    remarks="Status updated (seed data).", changed_by=random.choice(officer_objs).user,
                )
            created_count += 1

        self.stdout.write(self.style.SUCCESS(f"  ✓ {created_count} sample complaints created"))
        self.stdout.write(self.style.SUCCESS("Done! Mumbai Connect demo data is ready."))
        self.stdout.write(self.style.NOTICE(
            "\nLogin credentials:\n"
            "  Admin:    admin / Admin@1234\n"
            "  Officer:  officer1 / Officer@1234\n"
            "  Citizen:  citizen1 / Citizen@1234\n"
        ))
