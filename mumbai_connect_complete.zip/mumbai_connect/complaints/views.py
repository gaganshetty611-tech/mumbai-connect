from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.core.paginator import Paginator
from django.shortcuts import render, redirect, get_object_or_404
from django.db.models import Count, Q

from .models import Complaint, ComplaintPhoto, ComplaintStatusHistory
from .forms import ComplaintForm, ComplaintFilterForm
from .utils import notify_status_change


@login_required
def user_dashboard(request):
    complaints = Complaint.objects.filter(citizen=request.user)
    stats = {
        'total': complaints.count(),
        'submitted': complaints.filter(status='SUBMITTED').count(),
        'in_progress': complaints.filter(status__in=['UNDER_REVIEW', 'ASSIGNED', 'IN_PROGRESS']).count(),
        'resolved': complaints.filter(status__in=['RESOLVED', 'CLOSED']).count(),
    }
    recent = complaints.order_by('-created_at')[:5]
    category_breakdown = complaints.values('category').annotate(count=Count('id')).order_by('-count')
    return render(request, 'complaints/dashboard_user.html', {
        'stats': stats, 'recent': recent, 'category_breakdown': category_breakdown,
    })


@login_required
def submit_complaint(request):
    if request.method == 'POST':
        form = ComplaintForm(request.POST, request.FILES)
        if form.is_valid():
            complaint = form.save(commit=False)
            complaint.citizen = request.user
            complaint.save()

            # Handle multiple photo uploads
            photos = request.FILES.getlist('photos')
            for photo in photos[:5]:
                ComplaintPhoto.objects.create(complaint=complaint, image=photo)

            # Initial status history entry
            ComplaintStatusHistory.objects.create(
                complaint=complaint, status=Complaint.Status.SUBMITTED,
                remarks="Complaint submitted by citizen.", changed_by=request.user,
            )

            # Duplicate detection
            duplicates = complaint.find_possible_duplicates()
            if duplicates.exists():
                messages.warning(
                    request,
                    f"Note: {duplicates.count()} similar complaint(s) already exist nearby. "
                    f"Yours has still been recorded as {complaint.complaint_id}."
                )
            else:
                messages.success(request, f"Complaint submitted successfully! Your tracking ID is {complaint.complaint_id}.")

            notify_status_change(complaint, remarks="Complaint received.")
            return redirect('complaints:complaint_detail', complaint_id=complaint.complaint_id)
        messages.error(request, "Please correct the errors below.")
    else:
        form = ComplaintForm()
    return render(request, 'complaints/submit.html', {'form': form})


@login_required
def complaint_detail(request, complaint_id):
    complaint = get_object_or_404(Complaint, complaint_id=complaint_id)
    # Citizens can only view their own complaints; staff/officers can view all.
    if complaint.citizen != request.user and not (request.user.is_admin_role or request.user.is_officer_role):
        messages.error(request, "You do not have permission to view this complaint.")
        return redirect('complaints:user_dashboard')

    return render(request, 'complaints/detail.html', {
        'complaint': complaint,
        'history': complaint.status_history.all(),
        'photos': complaint.photos.all(),
    })


@login_required
def complaint_history(request):
    complaints = Complaint.objects.filter(citizen=request.user)
    filter_form = ComplaintFilterForm(request.GET or None)

    if filter_form.is_valid():
        q = filter_form.cleaned_data.get('q')
        category = filter_form.cleaned_data.get('category')
        status = filter_form.cleaned_data.get('status')
        ward = filter_form.cleaned_data.get('ward')
        if q:
            complaints = complaints.filter(Q(complaint_id__icontains=q) | Q(title__icontains=q))
        if category:
            complaints = complaints.filter(category=category)
        if status:
            complaints = complaints.filter(status=status)
        if ward:
            complaints = complaints.filter(ward=ward)

    paginator = Paginator(complaints.order_by('-created_at'), 10)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'complaints/history.html', {
        'page_obj': page_obj, 'filter_form': filter_form,
    })


def track_complaint(request):
    """Public complaint tracking by ID — no login required, matches
    the 'Search by Complaint ID' feature from the landing page."""
    complaint = None
    searched = False
    complaint_id = request.GET.get('complaint_id', '').strip()
    if complaint_id:
        searched = True
        complaint = Complaint.objects.filter(complaint_id__iexact=complaint_id).first()
    return render(request, 'complaints/track.html', {
        'complaint': complaint, 'searched': searched, 'complaint_id': complaint_id,
    })
