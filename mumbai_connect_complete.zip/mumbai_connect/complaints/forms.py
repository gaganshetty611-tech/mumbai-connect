from django import forms
from django.conf import settings
from .models import Complaint
from wards.models import Ward


class MultiFileInput(forms.ClearableFileInput):
    allow_multiple_selected = True


class MultiFileField(forms.FileField):
    def __init__(self, *args, **kwargs):
        kwargs.setdefault('widget', MultiFileInput(attrs={'multiple': True, 'class': 'form-control', 'accept': 'image/*'}))
        super().__init__(*args, **kwargs)

    def clean(self, data, initial=None):
        # When multiple files are posted, Django's request.FILES.getlist()
        # is used in the view instead; this field mainly renders the widget.
        return data


class ComplaintForm(forms.ModelForm):
    """Main complaint submission form (Step: details + location)."""
    photos = MultiFileField(required=False, label="Upload photos (up to 5)")

    class Meta:
        model = Complaint
        fields = ['category', 'title', 'description', 'ward', 'address', 'latitude', 'longitude']
        widgets = {
            'category': forms.Select(attrs={'class': 'form-select', 'id': 'id_category'}),
            'title': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Short summary, e.g. "Garbage pile near bus stop"'}),
            'description': forms.Textarea(attrs={'class': 'form-control', 'rows': 4, 'placeholder': 'Describe the issue in detail...'}),
            'ward': forms.Select(attrs={'class': 'form-select'}),
            'address': forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Landmark / street address'}),
            'latitude': forms.HiddenInput(attrs={'id': 'id_latitude'}),
            'longitude': forms.HiddenInput(attrs={'id': 'id_longitude'}),
        }

    def clean(self):
        cleaned = super().clean()
        lat, lng = cleaned.get('latitude'), cleaned.get('longitude')
        if lat is None or lng is None:
            raise forms.ValidationError("Please select the complaint location on the map or use GPS detection.")
        return cleaned


class ComplaintFilterForm(forms.Form):
    """Used on history/admin list pages for search & filter."""
    q = forms.CharField(required=False, widget=forms.TextInput(
        attrs={'class': 'form-control', 'placeholder': 'Search by Complaint ID, title...'}))
    category = forms.ChoiceField(required=False, choices=[('', 'All Categories')] + list(Complaint.Category.choices),
                                  widget=forms.Select(attrs={'class': 'form-select'}))
    status = forms.ChoiceField(required=False, choices=[('', 'All Statuses')] + list(Complaint.Status.choices),
                                widget=forms.Select(attrs={'class': 'form-select'}))
    ward = forms.ModelChoiceField(required=False, queryset=Ward.objects.all(), empty_label="All Wards",
                                   widget=forms.Select(attrs={'class': 'form-select'}))


class StatusUpdateForm(forms.Form):
    status = forms.ChoiceField(choices=Complaint.Status.choices, widget=forms.Select(attrs={'class': 'form-select'}))
    remarks = forms.CharField(required=False, widget=forms.Textarea(
        attrs={'class': 'form-control', 'rows': 2, 'placeholder': 'Optional remarks for this update'}))


class AssignOfficerForm(forms.Form):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        from officers.models import Officer
        self.fields['officer'] = forms.ModelChoiceField(
            queryset=Officer.objects.filter(is_active=True),
            widget=forms.Select(attrs={'class': 'form-select'}))
