import json
from django.contrib.auth.decorators import login_required, user_passes_test
from django.contrib import messages
from django.core.paginator import Paginator
from django.db.models import Count, Q
from django.db.models.functions import TruncMonth
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.utils import timezone

from accounts.models import User
from .models import Complaint, ComplaintStatusHistory
from .forms import ComplaintFilterForm, StatusUpdateForm, AssignOfficerForm
from .utils import notify_status_change
from wards.models import Ward


def staff_check(user):
    return user.is_authenticated and (user.is_admin_role or user.is_officer_role)


@login_required
@user_passes_test(staff_check, login_url='accounts:login')
def dashboard(request):
    total_users = User.objects.filter(role=User.Role.CITIZEN).count()
    total_complaints = Complaint.objects.count()
    pending = Complaint.objects.exclude(status__in=['RESOLVED', 'CLOSED']).count()
    resolved = Complaint.objects.filter(status__in=['RESOLVED', 'CLOSED']).count()

    recent_complaints = Complaint.objects.select_related('ward', 'citizen').order_by('-created_at')[:8]

    category_data = Complaint.objects.values('category').annotate(count=Count('id')).order_by('-count')
    status_data = Complaint.objects.values('status').annotate(count=Count('id')).order_by('-count')

    return render(request, 'admin_panel/dashboard.html', {
        'total_users': total_users,
        'total_complaints': total_complaints,
        'pending': pending,
        'resolved': resolved,
        'recent_complaints': recent_complaints,
        'category_data': list(category_data),
        'status_data': list(status_data),
    })


@login_required
@user_passes_test(staff_check, login_url='accounts:login')
def analytics(request):
    ward_data = (Complaint.objects.values('ward__name', 'ward__code')
                 .annotate(count=Count('id')).order_by('-count'))
    category_data = Complaint.objects.values('category').annotate(count=Count('id')).order_by('-count')

    monthly_trend = (Complaint.objects.annotate(month=TruncMonth('created_at'))
                      .values('month').annotate(count=Count('id')).order_by('month'))

    avg_resolution_days = None
    resolved_qs = Complaint.objects.filter(status='RESOLVED', resolved_at__isnull=False)
    if resolved_qs.exists():
        total_days = sum((c.resolved_at - c.created_at).days for c in resolved_qs)
        avg_resolution_days = round(total_days / resolved_qs.count(), 1)

    heatmap_points = list(
        Complaint.objects.exclude(latitude__isnull=True).exclude(longitude__isnull=True)
        .values_list('latitude', 'longitude')
    )

    context = {
        'ward_labels': json.dumps([w['ward__code'] or 'N/A' for w in ward_data]),
        'ward_counts': json.dumps([w['count'] for w in ward_data]),
        'category_labels': json.dumps([dict(Complaint.Category.choices).get(c['category'], c['category']) for c in category_data]),
        'category_counts': json.dumps([c['count'] for c in category_data]),
        'trend_labels': json.dumps([m['month'].strftime('%b %Y') for m in monthly_trend]),
        'trend_counts': json.dumps([m['count'] for m in monthly_trend]),
        'heatmap_points': json.dumps(heatmap_points),
        'avg_resolution_days': avg_resolution_days,
        'ward_data': ward_data,
        'category_data': category_data,
    }
    return render(request, 'admin_panel/analytics.html', context)


@login_required
@user_passes_test(staff_check, login_url='accounts:login')
def complaint_list(request):
    complaints = Complaint.objects.select_related('ward', 'citizen', 'assigned_officer').all()
    filter_form = ComplaintFilterForm(request.GET or None)

    if filter_form.is_valid():
        q = filter_form.cleaned_data.get('q')
        category = filter_form.cleaned_data.get('category')
        status = filter_form.cleaned_data.get('status')
        ward = filter_form.cleaned_data.get('ward')
        if q:
            complaints = complaints.filter(Q(complaint_id__icontains=q) | Q(title__icontains=q) |
                                            Q(citizen__username__icontains=q))
        if category:
            complaints = complaints.filter(category=category)
        if status:
            complaints = complaints.filter(status=status)
        if ward:
            complaints = complaints.filter(ward=ward)

    paginator = Paginator(complaints.order_by('-created_at'), 15)
    page_obj = paginator.get_page(request.GET.get('page'))

    return render(request, 'admin_panel/complaint_list.html', {
        'page_obj': page_obj, 'filter_form': filter_form,
    })


@login_required
@user_passes_test(staff_check, login_url='accounts:login')
def complaint_manage(request, complaint_id):
    complaint = get_object_or_404(Complaint, complaint_id=complaint_id)
    status_form = StatusUpdateForm(initial={'status': complaint.status})
    assign_form = AssignOfficerForm()

    if request.method == 'POST':
        if 'update_status' in request.POST:
            status_form = StatusUpdateForm(request.POST)
            if status_form.is_valid():
                complaint.status = status_form.cleaned_data['status']
                remarks = status_form.cleaned_data['remarks']
                if complaint.status == Complaint.Status.RESOLVED and not complaint.resolved_at:
                    complaint.resolved_at = timezone.now()
                complaint.save()
                ComplaintStatusHistory.objects.create(
                    complaint=complaint, status=complaint.status,
                    remarks=remarks, changed_by=request.user,
                )
                notify_status_change(complaint, remarks=remarks)
                messages.success(request, f"Status updated to '{complaint.get_status_display()}'.")
                return redirect('admin_panel:complaint_manage', complaint_id=complaint.complaint_id)

        elif 'assign_officer' in request.POST:
            assign_form = AssignOfficerForm(request.POST)
            if assign_form.is_valid():
                complaint.assigned_officer = assign_form.cleaned_data['officer']
                complaint.status = Complaint.Status.ASSIGNED
                complaint.save()
                ComplaintStatusHistory.objects.create(
                    complaint=complaint, status=Complaint.Status.ASSIGNED,
                    remarks=f"Assigned to {complaint.assigned_officer}.", changed_by=request.user,
                )
                notify_status_change(complaint, remarks=f"Assigned to {complaint.assigned_officer}.")
                messages.success(request, f"Complaint assigned to {complaint.assigned_officer}.")
                return redirect('admin_panel:complaint_manage', complaint_id=complaint.complaint_id)

        elif 'mark_spam' in request.POST:
            complaint.is_spam = True
            complaint.status = Complaint.Status.CLOSED
            complaint.save()
            messages.warning(request, "Complaint flagged as spam and closed.")
            return redirect('admin_panel:complaint_list')

        elif 'delete_complaint' in request.POST:
            complaint.delete()
            messages.warning(request, "Complaint deleted.")
            return redirect('admin_panel:complaint_list')

    return render(request, 'admin_panel/complaint_manage.html', {
        'complaint': complaint, 'status_form': status_form, 'assign_form': assign_form,
        'history': complaint.status_history.all(), 'photos': complaint.photos.all(),
    })


@login_required
@user_passes_test(staff_check, login_url='accounts:login')
def export_report_pdf(request):
    """
    Generates a simple text-based summary report. For a polished PDF,
    wire in WeasyPrint or reportlab (see README > 'Extending PDF export').
    This lightweight version keeps the project dependency-free by default.
    """
    complaints = Complaint.objects.select_related('ward', 'citizen').order_by('-created_at')[:500]
    lines = [
        "MUMBAI CONNECT - CIVIC COMPLAINTS REPORT",
        f"Generated: {timezone.now().strftime('%d %b %Y %H:%M')}",
        "-" * 70,
    ]
    for c in complaints:
        lines.append(
            f"{c.complaint_id} | {c.get_category_display():<25} | {c.get_status_display():<15} | "
            f"Ward: {c.ward.code if c.ward else 'N/A':<5} | {c.created_at.strftime('%d-%b-%Y')}"
        )
    content = "\n".join(lines)
    response = HttpResponse(content, content_type='text/plain')
    response['Content-Disposition'] = 'attachment; filename="mumbai_connect_report.txt"'
    return response
