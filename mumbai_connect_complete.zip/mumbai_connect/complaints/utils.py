from django.core.mail import send_mail
from django.conf import settings


def notify_status_change(complaint, remarks=""):
    """
    Creates an in-app Notification and sends an email alert to the
    citizen whenever a complaint's status changes.
    """
    from notifications.models import Notification

    message = f"Your complaint {complaint.complaint_id} is now '{complaint.get_status_display()}'."
    if remarks:
        message += f" Remarks: {remarks}"

    Notification.objects.create(
        user=complaint.citizen,
        complaint=complaint,
        message=message,
    )

    try:
        send_mail(
            subject=f"[Mumbai Connect] Update on {complaint.complaint_id}",
            message=(
                f"Dear {complaint.citizen.get_full_name() or complaint.citizen.username},\n\n"
                f"{message}\n\n"
                f"You can track full details by logging into your Mumbai Connect account.\n\n"
                f"— Mumbai Connect Civic Team"
            ),
            from_email=settings.DEFAULT_FROM_EMAIL,
            recipient_list=[complaint.citizen.email] if complaint.citizen.email else [],
            fail_silently=True,
        )
    except Exception:
        # Never let an email failure break the request/response cycle.
        pass
