import uuid
import math
from django.db import models
from django.conf import settings
from django.utils import timezone
from wards.models import Ward
from officers.models import Officer


class Complaint(models.Model):
    """Core complaint record submitted by a citizen."""

    class Category(models.TextChoices):
        GARBAGE = 'GARBAGE', 'Garbage Dump'
        POTHOLE = 'POTHOLE', 'Pothole'
        SEWAGE = 'SEWAGE', 'Sewage Overflow'
        FOOTPATH = 'FOOTPATH', 'Broken Footpath'
        WATERLOGGING = 'WATERLOGGING', 'Waterlogging'
        STREETLIGHT = 'STREETLIGHT', 'Streetlight Not Working'
        ILLEGAL_DUMPING = 'ILLEGAL_DUMPING', 'Illegal Dumping'
        OTHER = 'OTHER', 'Other'

    class Status(models.TextChoices):
        SUBMITTED = 'SUBMITTED', 'Submitted'
        UNDER_REVIEW = 'UNDER_REVIEW', 'Under Review'
        ASSIGNED = 'ASSIGNED', 'Assigned'
        IN_PROGRESS = 'IN_PROGRESS', 'In Progress'
        RESOLVED = 'RESOLVED', 'Resolved'
        CLOSED = 'CLOSED', 'Closed'

    class Priority(models.TextChoices):
        LOW = 'LOW', 'Low'
        MEDIUM = 'MEDIUM', 'Medium'
        HIGH = 'HIGH', 'High'
        CRITICAL = 'CRITICAL', 'Critical'

    complaint_id = models.CharField(max_length=20, unique=True, editable=False,
                                     help_text="Public tracking ID, e.g. MC-2026-00001")
    citizen = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='complaints')
    category = models.CharField(max_length=20, choices=Category.choices)
    title = models.CharField(max_length=150)
    description = models.TextField()

    ward = models.ForeignKey(Ward, on_delete=models.SET_NULL, null=True, blank=True, related_name='complaints')
    address = models.CharField(max_length=255, blank=True)
    latitude = models.FloatField(null=True, blank=True)
    longitude = models.FloatField(null=True, blank=True)

    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SUBMITTED)
    priority = models.CharField(max_length=10, choices=Priority.choices, default=Priority.MEDIUM)

    assigned_officer = models.ForeignKey(Officer, on_delete=models.SET_NULL, null=True, blank=True,
                                          related_name='assigned_complaints')

    is_duplicate_of = models.ForeignKey('self', on_delete=models.SET_NULL, null=True, blank=True,
                                         related_name='duplicates')
    is_spam = models.BooleanField(default=False)

    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    resolved_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['status']),
            models.Index(fields=['category']),
            models.Index(fields=['ward']),
        ]

    def __str__(self):
        return f"{self.complaint_id} - {self.get_category_display()}"

    def save(self, *args, **kwargs):
        if not self.complaint_id:
            self.complaint_id = self._generate_complaint_id()
        super().save(*args, **kwargs)

    @staticmethod
    def _generate_complaint_id():
        year = timezone.now().year
        prefix = f"MC-{year}-"
        last = Complaint.objects.filter(complaint_id__startswith=prefix).order_by('-complaint_id').first()
        next_num = 1
        if last:
            try:
                next_num = int(last.complaint_id.split('-')[-1]) + 1
            except (ValueError, IndexError):
                next_num = Complaint.objects.filter(complaint_id__startswith=prefix).count() + 1
        return f"{prefix}{next_num:05d}"

    @property
    def status_progress_percent(self):
        """Used to render the horizontal progress timeline bar."""
        order = [self.Status.SUBMITTED, self.Status.UNDER_REVIEW, self.Status.ASSIGNED,
                 self.Status.IN_PROGRESS, self.Status.RESOLVED, self.Status.CLOSED]
        try:
            idx = order.index(self.status)
        except ValueError:
            idx = 0
        return int((idx / (len(order) - 1)) * 100)

    def find_possible_duplicates(self):
        """
        Simple duplicate-detection heuristic: same category, within the
        configurable radius (haversine distance) and time window, excluding
        this complaint itself.
        """
        from django.conf import settings as dj_settings
        if self.latitude is None or self.longitude is None:
            return Complaint.objects.none()

        window_start = timezone.now() - timezone.timedelta(days=dj_settings.DUPLICATE_COMPLAINT_WINDOW_DAYS)
        candidates = Complaint.objects.filter(
            category=self.category,
            created_at__gte=window_start,
        ).exclude(pk=self.pk).exclude(latitude__isnull=True).exclude(longitude__isnull=True)

        radius = dj_settings.DUPLICATE_COMPLAINT_RADIUS_METERS
        nearby_ids = []
        for c in candidates:
            if _haversine_meters(self.latitude, self.longitude, c.latitude, c.longitude) <= radius:
                nearby_ids.append(c.pk)
        return Complaint.objects.filter(pk__in=nearby_ids)


def _haversine_meters(lat1, lon1, lat2, lon2):
    """Great-circle distance between two lat/lon points, in meters."""
    R = 6371000
    phi1, phi2 = math.radians(lat1), math.radians(lat2)
    dphi = math.radians(lat2 - lat1)
    dlambda = math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(phi1) * math.cos(phi2) * math.sin(dlambda / 2) ** 2
    return 2 * R * math.asin(math.sqrt(a))


def complaint_photo_path(instance, filename):
    return f"complaint_photos/{instance.complaint.complaint_id}/{filename}"


class ComplaintPhoto(models.Model):
    """Multiple photos can be attached as evidence per complaint."""
    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='photos')
    image = models.ImageField(upload_to=complaint_photo_path)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Photo for {self.complaint.complaint_id}"


class ComplaintStatusHistory(models.Model):
    """Audit trail powering the status timeline UI."""
    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='status_history')
    status = models.CharField(max_length=20, choices=Complaint.Status.choices)
    remarks = models.TextField(blank=True)
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True)
    changed_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['changed_at']
        verbose_name_plural = 'Complaint status histories'

    def __str__(self):
        return f"{self.complaint.complaint_id} -> {self.status}"


class ComplaintComment(models.Model):
    """Internal remarks / citizen follow-up messages on a complaint."""
    complaint = models.ForeignKey(Complaint, on_delete=models.CASCADE, related_name='comments')
    author = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['created_at']
