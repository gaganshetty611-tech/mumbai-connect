from django.contrib import admin
from .models import Complaint, ComplaintPhoto, ComplaintStatusHistory, ComplaintComment


class ComplaintPhotoInline(admin.TabularInline):
    model = ComplaintPhoto
    extra = 0


class ComplaintStatusHistoryInline(admin.TabularInline):
    model = ComplaintStatusHistory
    extra = 0
    readonly_fields = ('changed_at',)


@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ('complaint_id', 'category', 'status', 'priority', 'ward', 'citizen', 'created_at')
    list_filter = ('status', 'category', 'priority', 'ward', 'is_spam')
    search_fields = ('complaint_id', 'title', 'citizen__username')
    inlines = [ComplaintPhotoInline, ComplaintStatusHistoryInline]
    readonly_fields = ('complaint_id', 'created_at', 'updated_at')


@admin.register(ComplaintComment)
class ComplaintCommentAdmin(admin.ModelAdmin):
    list_display = ('complaint', 'author', 'created_at')
