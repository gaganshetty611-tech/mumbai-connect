from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion
import complaints.models


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('wards', '0001_initial'),
        ('officers', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Complaint',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('complaint_id', models.CharField(editable=False, help_text='Public tracking ID, e.g. MC-2026-00001', max_length=20, unique=True)),
                ('category', models.CharField(choices=[('GARBAGE', 'Garbage Dump'), ('POTHOLE', 'Pothole'), ('SEWAGE', 'Sewage Overflow'), ('FOOTPATH', 'Broken Footpath'), ('WATERLOGGING', 'Waterlogging'), ('STREETLIGHT', 'Streetlight Not Working'), ('ILLEGAL_DUMPING', 'Illegal Dumping'), ('OTHER', 'Other')], max_length=20)),
                ('title', models.CharField(max_length=150)),
                ('description', models.TextField()),
                ('address', models.CharField(blank=True, max_length=255)),
                ('latitude', models.FloatField(blank=True, null=True)),
                ('longitude', models.FloatField(blank=True, null=True)),
                ('status', models.CharField(choices=[('SUBMITTED', 'Submitted'), ('UNDER_REVIEW', 'Under Review'), ('ASSIGNED', 'Assigned'), ('IN_PROGRESS', 'In Progress'), ('RESOLVED', 'Resolved'), ('CLOSED', 'Closed')], default='SUBMITTED', max_length=20)),
                ('priority', models.CharField(choices=[('LOW', 'Low'), ('MEDIUM', 'Medium'), ('HIGH', 'High'), ('CRITICAL', 'Critical')], default='MEDIUM', max_length=10)),
                ('is_spam', models.BooleanField(default=False)),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('updated_at', models.DateTimeField(auto_now=True)),
                ('resolved_at', models.DateTimeField(blank=True, null=True)),
                ('assigned_officer', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='assigned_complaints', to='officers.officer')),
                ('citizen', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='complaints', to=settings.AUTH_USER_MODEL)),
                ('is_duplicate_of', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='duplicates', to='complaints.complaint')),
                ('ward', models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name='complaints', to='wards.ward')),
            ],
            options={
                'ordering': ['-created_at'],
            },
        ),
        migrations.CreateModel(
            name='ComplaintPhoto',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('image', models.ImageField(upload_to=complaints.models.complaint_photo_path)),
                ('uploaded_at', models.DateTimeField(auto_now_add=True)),
                ('complaint', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='photos', to='complaints.complaint')),
            ],
        ),
        migrations.CreateModel(
            name='ComplaintStatusHistory',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('status', models.CharField(choices=[('SUBMITTED', 'Submitted'), ('UNDER_REVIEW', 'Under Review'), ('ASSIGNED', 'Assigned'), ('IN_PROGRESS', 'In Progress'), ('RESOLVED', 'Resolved'), ('CLOSED', 'Closed')], max_length=20)),
                ('remarks', models.TextField(blank=True)),
                ('changed_at', models.DateTimeField(auto_now_add=True)),
                ('changed_by', models.ForeignKey(null=True, on_delete=django.db.models.deletion.SET_NULL, to=settings.AUTH_USER_MODEL)),
                ('complaint', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='status_history', to='complaints.complaint')),
            ],
            options={
                'verbose_name_plural': 'Complaint status histories',
                'ordering': ['changed_at'],
            },
        ),
        migrations.CreateModel(
            name='ComplaintComment',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('message', models.TextField()),
                ('created_at', models.DateTimeField(auto_now_add=True)),
                ('author', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, to=settings.AUTH_USER_MODEL)),
                ('complaint', models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name='comments', to='complaints.complaint')),
            ],
            options={
                'ordering': ['created_at'],
            },
        ),
        migrations.AddIndex(
            model_name='complaint',
            index=models.Index(fields=['status'], name='complaints__status_9e2a3a_idx'),
        ),
        migrations.AddIndex(
            model_name='complaint',
            index=models.Index(fields=['category'], name='complaints__categor_9c1b2b_idx'),
        ),
        migrations.AddIndex(
            model_name='complaint',
            index=models.Index(fields=['ward'], name='complaints__ward_id_7d4c5c_idx'),
        ),
    ]
