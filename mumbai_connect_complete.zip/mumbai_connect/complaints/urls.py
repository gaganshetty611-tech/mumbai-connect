from django.urls import path
from . import views

app_name = 'complaints'

urlpatterns = [
    path('dashboard/', views.user_dashboard, name='user_dashboard'),
    path('submit/', views.submit_complaint, name='submit_complaint'),
    path('history/', views.complaint_history, name='complaint_history'),
    path('track/', views.track_complaint, name='track_complaint'),
    path('<str:complaint_id>/', views.complaint_detail, name='complaint_detail'),
]
