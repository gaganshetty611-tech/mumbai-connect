from django.urls import path
from . import admin_views

app_name = 'admin_panel'

urlpatterns = [
    path('', admin_views.dashboard, name='dashboard'),
    path('analytics/', admin_views.analytics, name='analytics'),
    path('complaints/', admin_views.complaint_list, name='complaint_list'),
    path('complaints/<str:complaint_id>/', admin_views.complaint_manage, name='complaint_manage'),
    path('reports/export/', admin_views.export_report_pdf, name='export_report'),
]
