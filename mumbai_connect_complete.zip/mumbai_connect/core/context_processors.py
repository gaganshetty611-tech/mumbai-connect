from django.conf import settings


def site_context(request):
    """Makes site-wide constants and unread notification count available
    to every template without repeating boilerplate in each view."""
    unread_count = 0
    if request.user.is_authenticated:
        unread_count = request.user.notifications.filter(is_read=False).count()

    return {
        'SITE_NAME': settings.SITE_NAME,
        'EMERGENCY_CONTACTS': settings.EMERGENCY_CONTACTS,
        'unread_notification_count': unread_count,
    }
