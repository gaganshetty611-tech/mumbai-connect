from django.contrib import messages
from django.db.models import Count
from django.shortcuts import render, redirect
from complaints.models import Complaint
from wards.models import Ward


def home(request):
    stats = {
        'total_complaints': Complaint.objects.count(),
        'resolved': Complaint.objects.filter(status__in=['RESOLVED', 'CLOSED']).count(),
        'wards_covered': Ward.objects.count(),
        'in_progress': Complaint.objects.exclude(status__in=['RESOLVED', 'CLOSED']).count(),
    }
    categories = Complaint.Category.choices
    return render(request, 'home.html', {'stats': stats, 'categories': categories})


def about(request):
    return render(request, 'about.html')


def contact(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        messages.success(request, f"Thank you {name}, your message has been received. Our team will respond shortly.")
        return redirect('core:contact')
    return render(request, 'contact.html')


def faq(request):
    faqs = [
        ("How do I report a civic issue?", "Sign up for a free account, click 'Submit Complaint', choose a category, add photos and pinpoint the location on the map, then submit. You'll receive a unique Complaint ID to track progress."),
        ("How long does resolution take?", "Resolution time varies by category and severity. Most potholes and streetlight issues are resolved within 7-14 days; sanitation issues are typically addressed within 48-72 hours."),
        ("Can I track my complaint without logging in?", "Yes — use the 'Track Complaint' feature on the homepage and enter your Complaint ID to see live status."),
        ("What happens if I report a duplicate issue?", "Our system automatically checks for similar complaints in the same location and time window. Your complaint is still recorded, and you'll be notified if duplicates exist."),
        ("Who resolves my complaint?", "Complaints are routed to the relevant BMC ward officer or department (Sanitation, Roads, Water & Sewage, or Electrical) based on category and location."),
        ("How do I edit my profile or ward?", "Go to 'My Profile' after logging in to update your contact details, address, and ward."),
    ]
    return render(request, 'faq.html', {'faqs': faqs})
