from django.conf import settings
from django.db import migrations, models
import django.db.models.deletion


class Migration(migrations.Migration):

    initial = True

    dependencies = [
        ('wards', '0001_initial'),
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
    ]

    operations = [
        migrations.CreateModel(
            name='Officer',
            fields=[
                ('id', models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name='ID')),
                ('employee_id', models.CharField(max_length=20, unique=True)),
                ('department', models.CharField(choices=[('SANITATION', 'Sanitation Department'), ('ROADS', 'Roads & Infrastructure'), ('WATER', 'Water & Sewage'), ('ELECTRICAL', 'Electrical / Streetlights'), ('GENERAL', 'General Administration')], default='GENERAL', max_length=20)),
                ('designation', models.CharField(default='Ward Officer', max_length=100)),
                ('is_active', models.BooleanField(default=True)),
                ('user', models.OneToOneField(on_delete=django.db.models.deletion.CASCADE, related_name='officer_profile', to=settings.AUTH_USER_MODEL)),
                ('wards', models.ManyToManyField(blank=True, related_name='officers', to='wards.ward')),
            ],
        ),
    ]
