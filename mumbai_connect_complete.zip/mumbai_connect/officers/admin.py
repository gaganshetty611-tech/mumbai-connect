from django.contrib import admin
from .models import Officer


@admin.register(Officer)
class OfficerAdmin(admin.ModelAdmin):
    list_display = ('employee_id', 'user', 'department', 'designation', 'is_active')
    list_filter = ('department', 'is_active', 'wards')
    filter_horizontal = ('wards',)
    search_fields = ('employee_id', 'user__username', 'user__first_name', 'user__last_name')
