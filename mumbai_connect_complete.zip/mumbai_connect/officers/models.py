from django.db import models
from django.conf import settings
from wards.models import Ward


class Officer(models.Model):
    """
    A municipal officer responsible for resolving complaints within
    one or more wards. Linked 1-to-1 with a User account that has
    role=OFFICER so they can log in to a restricted dashboard view.
    """

    class Department(models.TextChoices):
        SANITATION = 'SANITATION', 'Sanitation Department'
        ROADS = 'ROADS', 'Roads & Infrastructure'
        WATER = 'WATER', 'Water & Sewage'
        ELECTRICAL = 'ELECTRICAL', 'Electrical / Streetlights'
        GENERAL = 'GENERAL', 'General Administration'

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='officer_profile')
    employee_id = models.CharField(max_length=20, unique=True)
    department = models.CharField(max_length=20, choices=Department.choices, default=Department.GENERAL)
    wards = models.ManyToManyField(Ward, related_name='officers', blank=True)
    designation = models.CharField(max_length=100, default='Ward Officer')
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return f"{self.user.get_full_name()} ({self.employee_id})"

    @property
    def active_case_count(self):
        return self.assigned_complaints.exclude(status__in=['RESOLVED', 'CLOSED']).count()
