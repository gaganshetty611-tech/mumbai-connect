# 🏙️ Mumbai Connect — Smart Civic Complaint Management System

A production-style, full-stack civic complaint portal built with **Django, Bootstrap 5, and MySQL/SQLite**, inspired by modern government e-governance platforms. Citizens report civic issues (garbage, potholes, sewage, waterlogging, streetlights, etc.) with photos and GPS location; municipal officers and admins triage, assign, and resolve them through a dashboard with analytics.

Built as a final-year CS project / portfolio piece — clean architecture, normalized schema, and real working features (not just mockups).

---

## ✨ Feature Overview

**Citizens**
- Registration & secure login (custom Django user model with roles)
- Submit complaints: category, description, up to 5 photos with live preview, GPS auto-detect or interactive OpenStreetMap picker, ward selection
- Automatic duplicate-complaint detection (same category + nearby location + recent time window)
- Complaint history with search/filter + pagination
- Public "Track by Complaint ID" (no login required)
- Visual status timeline (Submitted → Under Review → Assigned → In Progress → Resolved → Closed)
- Email + in-app notifications on every status change
- Editable profile with photo, ward, contact info

**Admin / Officer Dashboard**
- KPI widgets: total users, total complaints, pending, resolved
- Ward-wise & category-wise bar/doughnut charts (Chart.js)
- Monthly trend line chart
- Complaint hotspot map (OpenStreetMap markers)
- Search, filter, paginate all complaints
- View photo evidence, update status (with remarks + audit trail), assign to officers, mark spam, delete
- Downloadable complaint report

**Design**
- Blue / White / Green civic theme, fully responsive Bootstrap 5 layout
- Mumbai skyline-style hero section, hover cards, category icon grid
- Dark / Light mode toggle (persisted via localStorage)
- Accessible: skip-to-content link, semantic headings, keyboard-navigable nav/forms

---

## 🧱 Tech Stack

| Layer      | Technology                                   |
|------------|-----------------------------------------------|
| Frontend   | HTML5, CSS3, Bootstrap 5, vanilla JavaScript  |
| Backend    | Django 5 (Python)                             |
| Database   | MySQL (production) / SQLite (zero-config dev) |
| Images     | Pillow                                        |
| Maps       | Leaflet.js + OpenStreetMap (no API key needed)|
| Charts     | Chart.js                                      |

---

## 📁 Project Structure

```
mumbai_connect/
├── manage.py
├── requirements.txt
├── .env.example
├── mumbai_connect/          # Project settings, root urls, wsgi/asgi
├── core/                    # Home, About, Contact, FAQ + context processor
├── accounts/                # Custom User model, signup/login/profile
├── wards/                   # Ward model (24 BMC wards)
├── officers/                # Officer model (department, assigned wards)
├── complaints/              # Complaint, Photo, StatusHistory, Comment models
│   ├── views.py             # Citizen-facing views
│   ├── admin_views.py       # Staff dashboard/analytics/management views
│   ├── urls.py              # /complaints/...
│   ├── admin_urls.py        # /control-panel/... (app_name='admin_panel')
│   └── management/commands/seed_data.py
├── notifications/           # In-app notifications
├── templates/                # All HTML templates (mirrors app structure)
├── static/{css,js,img}/      # Theme CSS, map/preview/chart JS
└── media/                    # User-uploaded photos (created at runtime)
```

---

## 🚀 Installation (Development, SQLite — fastest path)

```bash
# 1. Clone / extract the project, then create a virtual environment
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate

# 2. Install dependencies
pip install Django==5.0.6 Pillow==10.3.0

# 3. Apply migrations (initial migration files are already included in the repo)
python manage.py migrate
# If you change any models later, regenerate with:
#   python manage.py makemigrations
#   python manage.py migrate

# 4. Seed demo data (24 Mumbai wards, admin/officer/citizen accounts, ~60 sample complaints)
python manage.py seed_data

# 5. Run the dev server
python manage.py runserver
```

Visit **http://127.0.0.1:8000/**

**Demo credentials (created by `seed_data`):**
| Role    | Username    | Password       |
|---------|-------------|----------------|
| Admin   | admin       | Admin@1234     |
| Officer | officer1    | Officer@1234   |
| Citizen | citizen1    | Citizen@1234   |

---

## 🐬 Switching to MySQL (Production)

```bash
pip install mysqlclient

# Create the database
mysql -u root -p -e "CREATE DATABASE mumbai_connect_db CHARACTER SET utf8mb4;"

# Copy env template and edit values
cp .env.example .env
```

Set in `.env` (or your shell environment):
```
DB_ENGINE=mysql
DB_NAME=mumbai_connect_db
DB_USER=root
DB_PASSWORD=your_password
DB_HOST=localhost
DB_PORT=3306
```

Then run migrations & seed data as above. `settings.py` automatically switches the `DATABASES` config when `DB_ENGINE=mysql` is set.

> Note: `0001_initial.py` migration files are included for every app (`wards`, `accounts`, `officers`, `complaints`, `notifications`), so a plain `python manage.py migrate` is enough on a fresh checkout — no `makemigrations` step is required unless you modify a model.

---

## 📧 Email Alerts

Defaults to Django's **console backend** (prints emails to the terminal) so it works out of the box with zero config. For real email delivery, set in `.env`:
```
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_HOST_USER=your_email@gmail.com
EMAIL_HOST_PASSWORD=your_app_password   # use a Gmail App Password, not your login password
```

---

## 🖨️ Extending PDF Export

The included "Download Report" button exports a clean `.txt` summary by default (dependency-free). For a polished PDF:
```bash
pip install reportlab
```
then extend `complaints/admin_views.py::export_report_pdf` to build a PDF canvas instead of plain text — the query logic (complaint list, ward/category info) is already assembled for you.

---

## 🗄️ Database Schema (Normalized)

- **User** (accounts) — extends AbstractUser; role (citizen/officer/admin), ward FK, phone, address
- **Ward** — 24 BMC wards with code, name, zone, lat/lng
- **Officer** — OneToOne with User; department, M2M wards, employee ID
- **Complaint** — citizen FK, ward FK, assigned_officer FK, category/status/priority enums, lat/lng, self-referential `is_duplicate_of`
- **ComplaintPhoto** — FK to Complaint, ImageField (multiple photos per complaint)
- **ComplaintStatusHistory** — audit trail powering the timeline UI
- **ComplaintComment** — internal remarks / follow-ups
- **Notification** — FK to User + optional Complaint, read/unread flag

All relationships use proper foreign keys with `on_delete` rules (`CASCADE` for owned children, `SET_NULL` for optional references) — no data duplication.

---

## 🌐 Deployment Guide (example: Ubuntu + Gunicorn + Nginx)

```bash
pip install gunicorn whitenoise
python manage.py collectstatic --noinput
```

Add to `settings.py` MIDDLEWARE (after SecurityMiddleware) for static file serving:
```python
'whitenoise.middleware.WhiteNoiseMiddleware',
```

Run with Gunicorn:
```bash
gunicorn mumbai_connect.wsgi:application --bind 0.0.0.0:8000 --workers 3
```

Put Nginx in front as a reverse proxy, terminate TLS there, and set:
```
DJANGO_DEBUG=False
DJANGO_ALLOWED_HOSTS=yourdomain.gov.in
```

For containerized deployment, wrap the above in a standard `Dockerfile` (Python 3.12 slim base) + `docker-compose.yml` alongside a MySQL service.

---

## 🔒 Security Notes

- CSRF protection on all forms (Django default)
- Password validation (min length, common-password checks)
- File uploads capped at 10MB; only 5 photos/complaint
- Staff-only views protected via `@user_passes_test`
- Remember to set a strong `DJANGO_SECRET_KEY` and `DJANGO_DEBUG=False` in production

---

## 🧪 Sample/Test Data

`python manage.py seed_data --complaints 100` (default 60) creates realistic demo data spanning all categories, statuses, and all 24 wards — ideal for demoing the analytics dashboard and heatmap immediately after setup.

---

## 📌 Honest Scope Notes

This is a complete, working Django implementation of the core system end-to-end (models, forms, views, templates, auth, dashboards, charts, maps, notifications, seed data). A couple of "nice-to-have" items from the original spec are implemented at a lightweight/extensible level rather than a heavyweight one, to keep the project dependency-light out of the box:
- **PDF export** ships as a plain-text report; swap in `reportlab`/`WeasyPrint` for a styled PDF (see above).
- **Heatmap** uses Leaflet circle markers sized/colored by density rather than a dedicated heatmap plugin (add `leaflet.heat` via CDN for a smoother gradient effect if desired).
- **Google Maps** was skipped in favor of **OpenStreetMap/Leaflet** since it requires no API key/billing account — swap the `map.js` tile layer for the Google Maps JS API if you have a key.

Everything else — auth, complaint lifecycle, admin dashboard, notifications, analytics, ward routing, duplicate detection — is fully functional.
